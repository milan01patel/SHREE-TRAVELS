<?php 
include('header.php');
include('db.php');
include('session.php'); 
?>
 
   <!-- *************** back button ****************** -->
   <!-- <div class="container">
<button type="button" class="btn"><a href="mybooking.php"> <img src="img/back.png" alt=""></a></button>
</div> -->
<!-- ************************************************ -->
<!-- <div class="container mt-2" >
<table class="table table-warning table-hover table-striped text-capitalize border border-dark border-3 text-center ">
  <thead style="color:maroon;">
    <tr class="fs-4">
      <th scope="col" class="pb-5 pt-4">booking id</th>
      <th scope="col" class="pb-5 pt-4">name</th>
      <th scope="col" class="pb-5 pt-4">email</th>
      <th scope="col" class="pb-5 pt-4">date</th>
	  <th scope="col" class="pb-5 pt-4">source</th>
      <th scope="col" class="pb-5 pt-4">destination</th>
	  <th scope="col" class="pb-5 pt-4">type</th>
	  <th scope="col" class="pb-5 pt-4">view</th>
    </tr>
  </thead>
	<tbody >
	<?php 
		$con =mysqli_connect("localhost","root","","shree");
		$no =0;
		$select=mysqli_query($con,"SELECT * FROM `bookings` WHERE `email`='$session_email'");
		while ($row=mysqli_fetch_array($select))
		{ 
			$no=$no+1;	
	 ?>
		<tr >
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['bookid']; ?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['firstname'] ;?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['email'];?></td>
			<td class="pt-4 pb-4 fs-5"><?php echo $row['date'];?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['source'];?></td>
            <td class="pt-4 pb-4 fs-5"><?php echo $row['destination'];?></td>
            <td class="pt-4 pb-4 fs-5"><?php echo $row['type'];?></td>
			<td class="pt-4 pb-4"><a class="btn btn-success btn-sm text-light" name="gobook" href="gotobook.php?id=<?php echo $row['id'];?>"> G O &nbsp FOR &nbsp B O O K</a></td> 
	 	</tr>
		
	<?php } ?>
	</tbody>
</table>
</div> -->

<?php 


$query = "select * from `bookings` where `email`='$session_email' ";  
$run = mysqli_query($con,$query);  
?>

<!-- **************************booking data******************************* -->
<div class="container mt-5 ">
<table  class="table table-striped text-center table-warning ">  
      <tr  class="text-danger">  
           <th>BUS ID</th>
           <th>DATE</th>
           
           <th>DOWNLOAD</th>
      </tr>  
      <?php    
           if ($num = mysqli_num_rows($run)>0) 
           {  
                while ($result = mysqli_fetch_assoc($run)) 
                {  
                    echo"<tr>
                            <td>".$result['bookid']."</td>
                           
                            <td>".$result['date']."</td>
                        
                            <td><a href='invoice.php?id=".$result['id']."' class='btn btn-outline-success'><b>VIEW</b></a></td>
                           
                        </tr>";
                }
           }
      ?>
 </table>
</div>

   <!-- search & sorting javascript -->