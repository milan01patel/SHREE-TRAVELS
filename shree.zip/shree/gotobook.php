<!-- <?php
echo(rand(1,28));
?> 
random number kri ae to seat 1 j book krva devani baki random number ma kyk krvanu
-->

<?php 
include('db.php');
include('header.php');
include('session.php'); 
?>
<?php 
      $select=mysqli_query($con,"SELECT * FROM `routes`");
      $row=mysqli_fetch_array($select);
?>
<?php
if(isset($_GET['id']))
{
  $id= $_GET['id'];}
  $query="select * from `routes` where `id`='$id'";
      $result= mysqli_query($con,$query);

      if(!$result)
      {
        // echo("query failed".mysqli_error());
      }
      else
      {
        $row=mysqli_fetch_assoc($result); 
      }
?>
<!-- ************************insert in database************************** -->
<?php 
     
     $con= mysqli_connect("localhost","root","","shree");

      if(isset($_POST['book']))
       {
        $fname =$_POST['fname'];
        $lname =$_POST['lname'];   
        $email =$_POST['email'];
        $date =$_POST['date']; 
        $from =$_POST['from'];
        $to =$_POST['to'];
        $type=$_POST['type'];
        $time=$_POST['time'];
        $price=$_POST['price'];
         $cardnumber=$_POST['cardnumber'];
         $pin=$_POST['pin'];
        $bookid="SRT".rand(100001,999999);
       
         $ins = mysqli_query($con,"INSERT INTO `bookings`(`firstname`,`lastname`,`email`,`date`,`source`,`destination`,`type`,`time`,`price`,`cardnumber`,`pin`,`bookid`)
        VALUES('$fname','$lname','$email','$date','$from','$to','$type','$time','$price','$cardnumber','$pin','$bookid')");
        $ins = mysqli_query($con,"INSERT INTO `bookings`(`firstname`,`lastname`,`email`,`date`,`source`,`destination`,`type`,`time`,`price`,`bookid`)
        VALUES('$fname','$lname','$email','$date','$from','$to','$type','$time','$price','$bookid')");
        if($ins)
        {
          echo '<script>alert("Thank you for your recent booking.")</script>';
        }
        else
        {
          echo "Fail";
        }
       }
        $bemail=mysqli_query($con, "SELECT * FROM `users` WHERE `email`='$session_email'")or die('Error In Session');
        $be=mysqli_fetch_array($bemail);
     ?> 
<!-- *********************************************************************** -->
<div class="container mt-5 bg-transparent " >
<form method="POST" class="row g-3 mt-3 fs-5 text-light p-4 rounded text-center" action="tpay.php" style="margin:25%; background-color: rgba(0, 0, 0, 0.750);">
<div class="mb-3 "><b>MAKE A FEW EASY STEP AND BOOK TICKET</b></div>
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">ENTER FIRST NAME</label>
    <input type="text" name="fname" class=" form-control text-center"  id="inputtext" required>
  </div>
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">ENTER LAST NAME</label>
    <input type="text" name="lname" class=" form-control text-center"  id="inputtext" required>
  </div>
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">ENTER YOUR EMAIL</label>
    <input type="email" name="email" class="text-light form-control text-center bg-transparent" readonly value="<?php echo $be['email']?>" id="inputemail" >
  </div>
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">ENTER DATE</label>
    <input type="date" name="date" class="form-control text-center"  id="inputtext" required>
  </div>
  <div class="col-md-6  ">
    <label for="inputText" class="form-label">SOURCE</label>
    <input type="text" name="from" class="text-light form-control text-center bg-transparent" readonly value="<?php echo $row['source'];?>" id="inputtext">
  </div>
  <div class="col-md-6  ">
    <label for="inputText" class="form-label">DESTINATION</label>
    <input type="text" name="to" class="text-light form-control text-center bg-transparent " readonly value="<?php echo $row['destination'];?>" id="inputtext">
  </div>
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">TYPE</label>
    <input type="text" name="type" class="text-light form-control text-center bg-transparent" readonly value="<?php echo $row['type']?>" id="inputtext">
  </div>
  <div class="col-md ">
    <label for="inputText" class="form-label">TIME</label>
    <input type="text" name="time" class="text-light form-control text-center bg-transparent" readonly value="<?php echo $row['time']?>" id="inputtext">
  </div>
  <div class="col-md">
    <label for="inputText" class="form-label">PRICE</label>
    <input type="text" name="price" class="text-danger form-control text-center bg-transparent" readonly value="<?php echo $row['prise']?>" id="inputtext">
  </div>
  
  <button type="submit" class="btn btn-secondary" name="book">B O O K</button>
</form>
</div>
<!-- *********************************************************************** -->
    <!-- bootstrap javascript link -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
