<?php 
include('header.php');
include('db.php');
$query = "select * from routes";  
$run = mysqli_query($con,$query);  
?>
<!-- *************** back button ****************** -->
 <div class="container">
<button type="button" class="btn"><a href="allinfo.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- ------------------------add new route--------------------- -->
<div class="mt-3 container ">
<a href='addroute.php'><button type="button" class="btn btn-warning"><i class="fa-solid fa-add"></i> ADD ROUTE </button></a>
</div>
<!-- ***************************search******************************* -->
<div class="container mt-5 btn-lg text-end text-danger">
    <b >serach route using source name -></b>
	<input type="text" placeholder="Search...(Source)" id="myInput" onkeyup="myFunction()" name="search" class="bg-dark text-light rounded ">
	<i class="fa-solid fa-magnifying-glass animate__animated animate__fadeInTopRight"></i>
</div>
<!-- **************************user data******************************* -->
<div class="container mt-1 ">
<table  class="table table-striped text-center table-warning " id="myTable">  
      <tr  class="text-danger">  
           <th>BUS NO</th>
           <th>FROM</th>
           <th>TO</th>
           <th>TYPE</th>
           <th>PRICE</th>
           <th>TIME</th>
           <th>EDIT ROUTE</th>
           <th>DELETE ROUTE</th>
      </tr>  
      <?php    
           if ($num = mysqli_num_rows($run)>0) 
           {  
                while ($result = mysqli_fetch_assoc($run)) 
                {  
                    echo"<tr>
                            <td>".$result['id']."</td>
                            <td>".$result['source']."</td>
                            <td>".$result['destination']."</td>
                            <td>".$result['type']."</td>
                            <td>".$result['prise']."</td>
                            <td>".$result['time']."</td>
                            <td><a href='a-edit.php?id=".$result['id']."' class='btn btn-outline-success'><b>EDIT</b></a></td>
                            <td><a href='a-deleteroute.php?id=".$result['id']."' class='btn btn-outline-danger'><b>Delete</b></a></td>
                        </tr>";
                }
           }
      ?>
 </table>
</div>
   <!-- search & sorting javascript -->
   <script>
	function myFunction() 
	{
  		var input, filter, table, tr, td, i, txtValue;
  		input = document.getElementById("myInput");
  		filter = input.value.toUpperCase();
  		table = document.getElementById("myTable");
  		tr = table.getElementsByTagName("tr");
  	for (i = 1; i < tr.length; i++) 
	{
    	td = tr[i].getElementsByTagName("td")[1];
    	if (td) 
		{
      	txtValue = td.textContent || td.innerText;
      	if (txtValue.toUpperCase().indexOf(filter) > -1)
		{
        	tr[i].style.display = "";
      	} 
		else 
		{
        	tr[i].style.display = "none";
      	}
    }       
  }
}
</script>