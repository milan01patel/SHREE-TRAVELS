<?php include('header.php'); ?>
<br>  
<div class="container">  
<button type="button" class="btn"><a href="index.php"><img src="img/home.png"></a><br>HOME</button>

</div>

<!-----------------------------many options------------------------------------>
<div class="container text-center mt-5">
  <div class="row " >
    <div class="col">
    <p class=" bg-light rounded-pill text-danger font-monospace">✧ BUS`S & ROUTES INFORMATION ( Edit & Add Route ) ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="a-schedule.php"> <img src="img/inlist.png" alt=""></a><br>EDIT & ADD ROUTE</button>
    </div>
    <div class="col">
    <p class="bg-light rounded-pill text-danger font-monospace">✧ BOOKING INFORMATION ✧<br>click ↓</p>
    <button type="button" class="btn"><a href="a-allbookinfo.php"> <img src="img/ubook.png" alt=""></a><br>BOOKINGS</button>
    </div>
  </div>
</div>
<div class="container text-center mt-5 mb-5">
  <div class="row " >
  <div class="col">
    <p class="bg-light rounded-pill text-danger font-monospace">✧ USER`S INFORMATION ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="a-users.php"> <i class="fa-solid fa-users fs-1 text-danger"></i></a></button>
  </div> 
  </div>
</div>