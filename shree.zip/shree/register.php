<!--Registration Page-->


<?php     
	include('header.php');

?>
<div><center><img src="img/user.png"/></center></div>
<div>
	<h2><center><b>User Registeration</center></b></h2><br><br>
<!-- **************************************************************************************************** -->
<?php 
     
     $con= mysqli_connect("localhost","root","","shree");

      if(isset($_POST['submit']))
       {
            
        $name =$_POST['name'];
        $number =$_POST['number'];   
        $email =$_POST['email'];
        $password =$_POST['password'];   
        $gender =$_POST['gender'];
        $dob=$_POST['dob'];
       
        $ins = mysqli_query($con,"INSERT INTO `users`(`name`,`number`,`email`,`password`,`gender`,`dob`)
        VALUES('$name','$number','$email','$password','$gender','$dob')");
        if($ins)
        {
            echo "R E G I S T E R  S U C C E S S ";
        }
        else
        {
          echo "Fail";
        }
       }
?>
<div >
<center><form method="post" action="" enctype="multipart/form-data" style="background-color: rgba(120, 50, 0, 0.350); border-radius:30px; width:900px;" >
<table class="table">
   
        <tr ><br>
            <td><h3> USER NAME : </h3></td> 
            <td colspan="2">
            <input type="Text" name="name" maxlength="50" placeholder="enter your full name" required>
            </td>
        </tr>
        <tr>
            <td>
            <h3>CONTACT NO.</h3></td> <td colspan="2"><input type="tel" name="number" min="10" max="10" placeholder="contact number" required>
        </td>
        </tr>
        <tr>
            <td>
                <h3>EMAIL ID : </h3></td> 
                <td colspan="2"><input type="email" name="email"  placeholder="email address" required >
            </td>
        </tr>
        <!-- pattern="(?=.\d)(?=.[a-z])(?=.*[A-Z]).{8,}" -->
        <tr>
            <td>
                <h3>PASSWORD : </h3></td> <td colspan="2"><input type="password" name="password" placeholder="password" required >
            </td>
        </tr>
        <td><h3>GENDER :</h3></td>
            <td>
                <input type="radio" id="html" name="gender" value="M" >
                <label for="M">Male</label>
                <input type="radio" id="css" name="gender" value="F">
                <label for="F">Female</label>
            </td>
        
       
        <tr>
            <td>
                <h3>DATE OF BIRTH :</h3></td><td colspan="2"><input type="date" name="dob"  placeholder="dd-mm-yyyy" required>
            </td>
        </tr>
        <tr>
            <td colspan="3">
                    <center><button type="Submit" class="btn btn-warning" name="submit">SUBMIT</button></center>
            </td>
        </tr>

</table>
</form></center>
</div>

</div>
<div align="center">
<h3><a href='login.php' style="color:maroon; text-decoration:none;">Log In</a></h3>
</div>
<br>

<!-- <?php include ('footer.php') ?>  -->


