<!-- <?php
echo(rand(1,28));
?> 
random number kri ae to seat 1 j book krva devani baki random number ma kyk krvanu
-->

<?php 
include('db.php');
include('header.php');
include('session.php'); 
?>
<!-- *********************************************************************** -->
<!-- ************************insert in database************************** -->
<?php 
     
     $con= mysqli_connect("localhost","root","","shree");

      if(isset($_POST['book']))
       {
        $name =$_POST['name'];
        $contact =$_POST['contact'];   
        $from =$_POST['from'];
        $to =$_POST['to'];   
        $email =$_POST['email'];
        $type =$_POST['type'];      
        $bookcode="SLEEP".rand(10001,99999);
       
        $ins = mysqli_query($con,"INSERT INTO `fullsleep_bookings`(`name`,`contact`,`datefrom`,`dateto`,`email`,`type`,`bookcode`)
        VALUES('$name','$contact','$from','$to','$email','$type','$bookcode')");
        if($ins)
        {
          echo '<script>alert("Thank you for your recent booking.")</script>';
        }
        else
        {
          echo '<script>alert("SOMTHING ELSE👾")</script>';
        }
       }
        $bemail=mysqli_query($con, "SELECT * FROM `users` WHERE `email`='$session_email'")or die('Error In Session');
        $be=mysqli_fetch_array($bemail);
     ?> 
       <!-- *************** back button ****************** -->
 <div class="container">
<button type="button" class="btn"><a href="fullbook.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- *********************************************************************** -->
<div class="container mt-5 bg-transparent " >
<form method="POST" class="row g-3 mt-3 fs-5 text-light p-4 rounded text-center " style="margin:25%; background-color: rgba(0, 0, 0, 0.750);">
<div class="mb-3 text-dark rounded-circle" style="background-color:bisque;"><b> BOOK FULL BUS </b></div>
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">FULL NAME</label>
    <input type="text" name="name" class=" form-control text-center" min="6"  id="inputtext" required>
  </div>
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">CONTACT NUMBER</label>
    <input type="text" name="contact" class=" form-control text-center" value="<?php echo $be['number']?>"  id="inputtext" min="10" max="10" required >
  </div>
 
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">JOURNEY FROM</label>
    <input type="date" name="from" class="form-control text-center"  id="inputtext" required>
  </div>
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">JOURNEY TO</label>
    <input type="date" name="to" class="form-control text-center"  id="inputtext" required>
  </div>

  <div class="col-md-6 ">
    <label for="inputText" class="form-label">YOUR EMAIL</label>
    <input type="email" name="email" class="text-light form-control text-center bg-transparent" readonly value="<?php echo $be['email']?>" id="inputemail" >
  </div>
    
  <div class="col-md-6 ">
    <label for="inputText" class="form-label">TYPE</label>
    <input type="text" name="type" class="text-light form-control text-center bg-transparent" readonly value="SLEEP" id="inputtext">
  </div>
  
  <button type="submit" class="btn btn-secondary" name="book">B O O K</button>

</form>
</div>
<!-- *********************************************************************** -->
    <!-- bootstrap javascript link -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
