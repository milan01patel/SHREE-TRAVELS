<?php
    include('header.php');
?>

	<!-- *************** back button ****************** -->
    <div class="container">
<button type="button" class="btn"><a href="busbook.php"> <img src="img/back.png" alt=""></a></button>
</div>
    <!-- ************************************** -->
    <b ><CENTER class="container fs-3" style="background-color:#F8F8FF;"> BOOK FULL BUS FROM HERE</CENTER></b>
    <!-- *********************************select options********************************* -->
<div class="container mt-1" >
<div class="row" >

    <div class="card mt-5 mb-5" style="width: 30rem;background-color:#D2B48C;">
    <p class="card-text bg-light mt-2 rounded-pill">28 seats seater bus</p>
    <img src="img/bus-set/semi.jpg" class="img-thumbnail mt-2" style="width: 30rem; height:200px; " alt="...">
    <div class="card-body">
    
    <a href="full_seat.php"><button class="btn btn-outline-dark">GO TO BOOK</button></a>
    </div>
    <b class="text-danger mb-2 rounded p-2" style="background-color:bisque;">* We Will Charge Price For This Type Bus 𝟑𝟓rs/km. <br>* Fees Included If You Need Extra Facilities.</b>
    </div>
    <!-- -------------------------------------------------------------------------------------------------------- -->
    <div class="card mt-5 mb-5" style="width: 30rem;background-color:#D2B48C; ">
    <p class="card-text bg-light mt-2 rounded-pill">24 seats sleeper bus</p>
    <img src="img/bus-set/sofa.jpg" class="img-thumbnail mt-2" style="width: 30rem; height:200px; " alt="...">
    <div class="card-body">
    
    <a href="full_sleep.php"><button class="btn btn-outline-dark">GO TO BOOK</button></a>
    </div>
    <b class="text-danger mb-2 rounded p-2" style="background-color:bisque;">* We Will Charge Price For This Type Bus  𝟒𝟎rs/km. <br>* Fees Included If You Need Extra Facilities. </b>
    </div>
    
</div>
</div>