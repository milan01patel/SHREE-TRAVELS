<!doctype html>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>manage password</title>
   
  </head>
  <body class="bclr" >
    
    <div class="container mt-5 py-5" >
    <div class="container-fluid p-1 bg-dark text-white text-center">
        <h1>Forget Password</h1>
    </div><br>
    
    <form method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Registered Email</label>
        <input type="email" name="cemail" required class="form-control" id="exampleInputPassword1">
      </div>
      <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">New Password</label>
        <input type="password" name="npassword" required class="form-control" id="exampleInputPassword1">
      </div>
      <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Confirm Password</label>
        <input type="password" name="cpassword" required class="form-control" id="exampleInputPassword1">
      </div>
   
    <div class="reminder mt-5" >
      <center>
        <button name="save" type="submit" value="save" class="btn btn-success ">FORGET</button>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href='login.php'><button type="button" class="btn btn-warning "></i>LOGIN </button></a>
      </center>

    </div>
    </form>

    </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  </body>
</html>
<?php
  $con= mysqli_connect("localhost","root","","shree");
  
  $result = mysqli_query($con,"SELECT `email` FROM users") or die('Error In Session');
  $row = mysqli_fetch_array($result);
  $uemail = $row['email'];

  if (isset($_POST['save'])) 
  {
    $cemail = $_POST['cemail'];

    $npassword = $_POST['npassword'];

    $cpassword = $_POST['cpassword'];

    if ($cemail == $uemail  || $npassword == $cpassword ) 
    {
        $result1 = mysqli_query($con,"UPDATE users SET `password`='$npassword' where email='$cemail'");
        echo '<script>alert("Your Password Change Successfull.")</script>';
    } 
    else
    {
      echo '<script>alert("Somthing Else !!")</script>';    
    }
  }
?>