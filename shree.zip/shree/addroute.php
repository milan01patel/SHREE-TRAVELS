<?php
    include("header.php");
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="mt-5">
	<h2><center><b>ADD ROUTE FROM HERE</center></b></h2><br><br>
</div>
<!-- **************************************************************************************************** -->
<?php 
     
     $con= mysqli_connect("localhost","root","","shree");

      if(isset($_POST['add']))
       {
            
        $from =$_POST['from'];
        $to =$_POST['to'];   
        $type =$_POST['type'];
        $prise =$_POST['prise'];   
        $time =$_POST['time'];
       
        $ins = mysqli_query($con,"INSERT INTO `routes`(`source`,`destination`,`type`,`prise`,`time`)
        VALUES('$from','$to','$type','$prise','$time')");

        if($ins)
        {
            echo '<script>alert("ROUTE ADDED SUCCESSFULL..");</script>';
        }
        else
        {
            echo"fail";
        }
       }
     ?>
<div >
<center><form method="post" action="" style=" background-color: rgba(120, 50, 0, 0.350); border-radius:30px; width:800px;" >
<table class="table text-center">
   
        <tr >
            <td><h3> FROM : </h3></td> 
            <td colspan="2">
            <input type="Text" name="from" maxlength="50" placeholder="enter source">
            </td>
        </tr>
        <tr ><br>
            <td><h3> TO : </h3></td> 
            <td colspan="2">
            <input type="Text" name="to" maxlength="50" placeholder="enter destination">
            </td>
        </tr>
        <tr ><br>
            <td><h3> TYPE : </h3></td> 
            <td colspan="2">
            <input type="Text" name="type" maxlength="50" placeholder="enter type of bus">
            </td>
        </tr>
        <tr ><br>
            <td><h3> PRISE : </h3></td> 
            <td colspan="2">
            <input type="text" name="prise" placeholder="enter prise">
            </td>
        </tr>
        <tr ><br>
            <td><h3> TIME : </h3></td> 
            <td colspan="2">
            <input type="Text" name="time" maxlength="50" placeholder="enter time">
            </td>
        </tr>
        <tr>
            <td colspan="3">
                    <center><button type="add" class="btn btn-warning" name="add">A D D</button></center>
            </td>
        </tr>

</table>
</form></center>
</div>
<div align="center">
<h3><a href='a-schedule.php' style="color:maroon; text-decoration:none;">GO TO BACK</a></h3>
</div>
<br>

<!-- <?php include ('footer.php') ?>  -->


