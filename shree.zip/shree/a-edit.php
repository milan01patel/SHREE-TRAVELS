<?php 
include('db.php');
?>
<?php 
      $select=mysqli_query($con,"SELECT * FROM `routes`");
      $row=mysqli_fetch_array($select);
?>
<?php 

    if(isset(
    
        $_POST['change'])){  
        $id= $_GET['id'];
        $source =$_POST['source'];
        $destination =$_POST['destination'];
        $type =$_POST['type'];
        $prise =$_POST['prise'];
        $time =$_POST['time'];
      
    $edits = mysqli_query($con,"UPDATE `routes` SET `prise`='$prise',`time`='$time' WHERE `id` = '$id'");
    
     if($edits)
     {
           header("location:a-schedule.php"); 
     }
     else{
      echo 'fail';
     }
    }
?> 

<?php
if(isset($_GET['id']))
{
  $id= $_GET['id'];}
  $query="select * from `routes` where `id`='$id'";
      $result= mysqli_query($con,$query);

      if(!$result)
      {
        echo("query failed".mysqli_error());
      }
      else
      {
        $row=mysqli_fetch_assoc($result); 
      }
?>
 
<div class="container py-5 mt-5 border bg-warning ">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      
  <form method="POST" enctype="multipart/form-data">
      <h1> EDIT ROUTE FROM HERE</h1><br>     
      <div class="mb-3">
        <label for="disabledTextInput" class="form-label">SOURCE (IT`S NOT FOR CHANGE)</label>
        <input  id="disabledTextInput" class="form-control" disabled="disabled"  value="<?php echo $row['source'];?>" name="source">
      </div>
      <div class="mb-3">
        <label for="disabledTextInput" class="form-label">DESTINATION (IT`S NOT FOR CHANGE)</label>
        <input  id="disabledTextInput" class="form-control" disabled="disabled"  value="<?php echo $row['destination'];?>" name="destination">
      </div>
      <div class="mb-3">
        <label for="disabledTextInput" class="form-label">TYPE (IT`S NOT FOR CHANGE)</label>
        <input  id="disabledTextInput" class="form-control" disabled="disabled"  value="<?php echo $row['type'];?>" name="type">
      </div>
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">PRISE</label>
        <input type="text" class="form-control" value="<?php echo $row['prise'];?>" name="prise" >
      </div>
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">TIME</label>
        <input type="text" class="form-control" value="<?php echo $row['time'];?>" name="time" >
      </div>
      <!-- <div class="mb-3">
        <label for="disabledTextInput" class="form-label">Email(IT`S NOT CHANGEABLE)</label>
        <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['email'];?>" name="email">
      </div> -->
      <button type="submit" class="btn btn-secondary" name="change">CHANGE</button>
  </form>
</div>
    <!-- bootstrap javascript link -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
