<!-- ----------database valu schedule leva mate-------- -->

<?php
    include ("header.php");
    include ('db.php');
?>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	
	<div>
<!-- *************** back button ****************** -->
<div class="container">
<button type="button" class="btn"><a href="busbook.php"> <img src="img/back.png" alt=""></a></button>
</div>
	<!-- ***************************search******************************* -->
	<div class="container pb-2 mt-5 btn-lg " style="text-align:center; ">
	<b>Find Your Source ➪ </b>
	<input type="text" placeholder="Search...(Source)" id="myInput" onkeyup="myFunction()" name="search" class="bg-dark text-light rounded ">
	<i class="fa-solid fa-magnifying-glass animate__animated animate__fadeInTopRight"></i>
	</div>
	
	
<!-- ****************************SCHEDULE NU TABLE************************** -->
 
<div class="container mt-2" >
<table class="table table-warning table-hover table-striped text-capitalize border border-dark border-3 text-center " id="myTable">
  <thead style="color:maroon;">
    <tr class="fs-4">
      <th scope="col" class="pb-5 pt-4">BUS NO</th>
      <th scope="col" class="pb-5 pt-4">FROM</th>
      <th scope="col" class="pb-5 pt-4">TO</th>
      <th scope="col" class="pb-5 pt-4">TYPE</th>
	  <th scope="col" class="pb-5 pt-4">PRICE</th>
      <th scope="col" class="pb-5 pt-4">TIME</th>
	  <th scope="col" class="pb-5 pt-4">BOOK TICKET</th>
    </tr>
  </thead>
	<tbody >
	<?php 
		$con =mysqli_connect("localhost","root","","shree");
		$no =0;
		$select=mysqli_query($con,"SELECT * FROM `routes`");
		while ($row=mysqli_fetch_array($select))
		{ 
			$no=$no+1;	
	 ?>
		<tr >
	 		<td class="pt-4 pb-4 fs-5" scope="row"><?php echo $no;?></td>	

	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['source'];?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['destination'] ;?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['type'];?></td>
			<td class="pt-4 pb-4 fs-5"><?php echo $row['prise'];?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['time'];?></td>
			<td class="pt-4 pb-4"><a class="btn btn-success btn-sm text-light" name="gobook" href="gotobook.php?id=<?php echo $row['id'];?>"> G O &nbsp FOR &nbsp B O O K</a></td> 
      		</td> 
	 	</tr>
		
	<?php } ?>
	</tbody>
</table>
</div>

			<!-- search & sorting javascript -->
<script>
	function myFunction() 
	{
  		var input, filter, table, tr, td, i, txtValue;
  		input = document.getElementById("myInput");
  		filter = input.value.toUpperCase();
  		table = document.getElementById("myTable");
  		tr = table.getElementsByTagName("tr");
  	for (i = 1; i < tr.length; i++) 
	{
    	td = tr[i].getElementsByTagName("td")[1];
    	if (td) 
		{
      	txtValue = td.textContent || td.innerText;
      	if (txtValue.toUpperCase().indexOf(filter) > -1)
		{
        	tr[i].style.display = "";
      	} 
		else 
		{
        	tr[i].style.display = "none";
      	}
    }       
  }
}
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<!-- <div class="container">
	<a class="btn btn-success" href="index.php">Add Data</a>
</div> -->