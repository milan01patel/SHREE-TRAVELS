<?php include ('header.php');?>
  <!-- *************** back button ****************** -->
  <div class="container">
<button type="button" class="btn"><a href="busbook.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- **************************************************** -->
<div class="container text-center mt-5 text-danger ">
   <h1 class="bg-light"><b>BUS _PHOTOS_ GALLARY</b></h1>
</div>
<!-- ----------------------------------------------------- -->
<div class="container mt-5">
<div class="row">
    <div class="card" style="width: 30rem; background-color:bisque">
    <img src="img/bus-set/set1.jpg" class="img-thumbnail mt-2" alt="...">
    <div class="card-body">
    <p class="card-text">Semi-sleeper bus.(seater)</p>
    </div>
    </div>
    
    <div class="card" style="width: 30rem; background-color:bisque">
    <img src="img/bus-set/set2.jpg" class="img-thumbnail mt-2" alt="...">
    <div class="card-body">
    <p class="card-text">Sleeper bus.</p>
    </div>
    </div>
</div>
</div>

<!-- ----------------------------------------------------- -->
<div class="container mt-5">
<div class="row">
    <div class="card" style="width: 30rem; background-color:bisque">
    <img src="img/bus-set/seat.jpg" class="img-thumbnail mt-2" alt="...">
    <div class="card-body">
    <p class="card-text">Semi-sleeper seats are provide on seating bus.</p>
    </div>
    </div>
    
    <div class="card" style="width: 30rem; background-color:bisque">
    <img src="img/bus-set/sleep.jpg" class="img-thumbnail mt-2" alt="...">
    <div class="card-body">
    <p class="card-text">This type sofa we will provide on sleeping bus.</p>
    </div>
    </div>
</div>
</div>
<!-- ----------------------------------------------------- -->
<div class="container mt-1" >
<div class="row" >

    <div class="card mt-5 mb-5" style="width: 30rem;background-color:bisque;">
    
    <img src="img/bus-set/semi.jpg" class="img-thumbnail mt-2 mb-3" style="width: 30rem; height:200px; " alt="...">
    <div class="card-body">
    <p class="card-text">28 SEATS</p>
    </div>
    
    </div>
    <div class="card mt-5 mb-5" style="width: 30rem;background-color:bisque;">
    
    <img src="img/bus-set/sofa.jpg" class="img-thumbnail mt-2 mb-3" style="width: 30rem; height:200px; " alt="...">
    <div class="card-body">
    <p class="card-text">36 SEATS</p>
    </div>

    </div>
    
</div>
</div>