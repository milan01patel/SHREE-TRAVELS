
 <?php   
 include 'db.php';  
 if (isset($_GET['uid'])) {  
      $uid = $_GET['uid'];  
      $query = "DELETE FROM `users` WHERE uid = '$uid'";  
      $run = mysqli_query($con,$query);  
      if ($run) {  
           header('location:a-users.php');  
      }else{  
           echo "Error: ".mysqli_error($con);  
      }  
 }  
 ?>  