-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2024 at 06:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shree`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'shree', 'shree@gmail.com', 'Shree1');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` varchar(10) NOT NULL,
  `source` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `time` varchar(6) NOT NULL,
  `price` varchar(4) NOT NULL,
  `bookid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `firstname`, `lastname`, `email`, `date`, `source`, `destination`, `type`, `time`, `price`, `bookid`) VALUES
(32, 'bak', 'hsf', 'lio@gmail.com', '2024-10-03', 'Ahemdabad', 'Junagadh', 'seater', '20:00', '300', 'SRT379350'),
(33, 'bak', 'hsf', 'lio@gmail.com', '2024-10-03', 'Ahemdabad', 'Junagadh', 'seater', '20:00', '300', 'SRT379350'),
(34, 'lio', 'zim', 'lio@gmail.com', '', 'Ahemdabad', 'Junagadh', '', '', '550', 'SRT841912'),
(35, 'milan', 'patel', 'lio@gmail.com', '2024-11-01', 'Junagadh', 'Ahemdabad', 'Seater', '20:00', '300', 'SRT383015'),
(36, 'Jiya', 'Raiz', 'jiya@gmail.com', '2024-09-30', 'Junagadh', 'Ahemdabad', 'Seater', '20:00', '300', 'SRT335817'),
(37, 'Jiya', 'raiz', 'jiya@gmail.com', '2024-12-11', 'Vdodara ', 'Rajkot', 'seater', '17:00', '380', 'SRT780882'),
(38, 'Jiya', 'raiz', 'jiya@gmail.com', '2024-12-11', 'Vdodara ', 'Rajkot', 'seater', '17:00', '380', 'SRT780882'),
(39, 'Jiya', 'raiz', 'jiya@gmail.com', '2024-12-11', 'Vdodara ', 'Rajkot', 'seater', '17:00', '380', 'SRT713638'),
(40, 'Jiya', 'raiz', 'jiya@gmail.com', '2024-12-11', 'Vdodara ', 'Rajkot', 'seater', '17:00', '380', 'SRT169272'),
(41, 'Jiya', 'raiz', 'jiya@gmail.com', '2024-12-11', 'Vdodara ', 'Rajkot', 'seater', '17:00', '380', 'SRT672228');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'user', 'user@gmail.com', 'good travel services.', 'wow, good services provides by your staf on my trip.'),
(2, 'LIO', 'lio@gmail.com', 'good portal', 'your ticket portal different from other so it`s good portal for bookings.'),
(3, 'Jiya Raiz', 'jiya@gmail.com', 'good update', 'very easy after your web update.');

-- --------------------------------------------------------

--
-- Table structure for table `fullseat_bookings`
--

CREATE TABLE `fullseat_bookings` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `datefrom` varchar(10) NOT NULL,
  `dateto` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL,
  `bookcode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fullseat_bookings`
--

INSERT INTO `fullseat_bookings` (`id`, `name`, `contact`, `datefrom`, `dateto`, `email`, `type`, `bookcode`) VALUES
(1, 'Jiya Raiz', '7656565656', '2024-09-25', '2024-09-28', 'jiya@gmail.com', 'SEAT', 'SEAT77581');

-- --------------------------------------------------------

--
-- Table structure for table `fullsleep_bookings`
--

CREATE TABLE `fullsleep_bookings` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `datefrom` varchar(10) NOT NULL,
  `dateto` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL,
  `bookcode` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fullsleep_bookings`
--

INSERT INTO `fullsleep_bookings` (`id`, `name`, `contact`, `datefrom`, `dateto`, `email`, `type`, `bookcode`) VALUES
(1, 'Jiya Raiz', '7656565656', '2024-09-29', '2024-10-04', 'jiya@gmail.com', 'SLEEP', 'SEAT69740');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` int(11) NOT NULL,
  `source` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `prise` varchar(50) NOT NULL,
  `time` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `source`, `destination`, `type`, `prise`, `time`) VALUES
(1, 'Ahemdabad', 'Junagadh', 'seater', '330', '20:00'),
(2, 'Ahemdabad', 'Junagadh', 'sleeper', '550', '19:00'),
(3, 'Ahemdabad', 'Junagadh', 'seater', '300', '07:00'),
(4, 'Ahemdabad', 'Junagadh', 'sleeper', '550', '08:00'),
(5, 'Ahemdabad', 'Gandhinagar', 'seater', '60', '06:00'),
(6, 'Ahemdabad', 'Gandhinagar', 'seater', '50', '12:00'),
(7, 'Ahemdabad', 'Rajkot', 'seater', '220', '20:00'),
(8, 'Ahemdabad', 'Rajkot', 'sleeper', '400', '19:00'),
(9, 'Ahemdabad', 'Vadodara', 'seater', '150', '20:00'),
(10, 'Ahemdabad', 'Vadodara', 'sleeper', '280', '19:00'),
(11, 'Ahemdabad', 'Surat', 'seater', '280', '20:00'),
(12, 'Ahemdabad', 'Surat', 'sleeper', '500', '19:00'),
(13, 'Gandhinagar', 'Ahemdabad', 'seater', '60', '06:00'),
(14, 'Gandhinagar', 'Ahemdabad', 'seater', '60', '18:00'),
(15, 'Gandhinagar', 'Junagadh', 'seater', '350', '19:00'),
(16, 'Gandhinagar', 'Junagadh', 'sleeper', '600', '18:00'),
(17, 'Gandhinagar', 'Rajkot', 'Seater', '280', '19:00'),
(18, 'Gandhinagar', 'Rajkot', 'sleeper', '450', '18:00'),
(19, 'Gandhinagar', 'Vadodara', 'Seater', '200', '19:00'),
(20, 'Gandhinagar', 'Vadodara', 'sleeper', '310', '18:00'),
(21, 'Gandhinagar', 'Surat', 'Seater', '320', '19:00'),
(22, 'Gandhinagar', 'Surat', 'sleeper', '650', '18:00'),
(23, 'Junagadh', 'Ahemdabad', 'Seater', '300', '20:00'),
(24, 'Junagadh', 'Ahemdabad', 'sleeper', '550', '19:00'),
(25, 'Junagadh', 'Rajkot', 'Seater', '120', '07:00'),
(26, 'Junagadh', 'Vadodara', 'seater', '430', '18:00'),
(27, 'Junagadh', 'Vadodara', 'sleeper', '600', '19:00'),
(28, 'Junagadh', 'Surat', 'seater', '500', '18:00'),
(29, 'Junagadh', 'Surat', 'sleeper', '620', '19:00'),
(30, 'Junagadh', 'Gandhinagar', 'seater', '350', '20:00'),
(31, 'Junagadh', 'Gandhinagar', 'sleeper', '600', '19:00'),
(32, 'Rajkot ', 'Ahemdabad', 'seater', '220', '22:00'),
(33, 'Rajkot ', 'Ahemdabad', 'sleeper', '400', '21:00'),
(34, 'Rajkot ', 'Gandhinagar', 'seater', '270', '22:00'),
(35, 'Rajkot ', 'Gandhinagar', 'sleeper', '420', '21:00'),
(36, 'Rajkot ', 'Junagadh', 'seater', '120', '07:00'),
(37, 'Rajkot ', 'Surat', 'seater', '320', '20:00'),
(38, 'Rajkot ', 'Surat', 'sleeper', '580', '21:00'),
(39, 'Rajkot ', 'Vadodara', 'seater', '280', '21:00'),
(40, 'Rajkot ', 'Vadodara', 'sleeper', '550', '21:00'),
(41, 'Surat ', 'Ahemdabad', 'seater', '280', '19:00'),
(42, 'Surat ', 'Ahemdabad', 'sleeper', '500', '20:00'),
(43, 'Surat ', 'Gandhinagar', 'seater', '320', '19:00'),
(44, 'Surat ', 'Gandhinagar', 'sleeper', '650', '20:00'),
(45, 'Surat ', 'Vadodara', 'seater', '130', '19:00'),
(46, 'Surat ', 'Vadodara', 'sleeper', '220', '20:00'),
(47, 'Surat ', 'Junagadh', 'seater', '500', '18:00'),
(48, 'Surat ', 'Junagadh', 'sleeper', '620', '21:00'),
(49, 'Surat ', 'Rajkot', 'seater', '320', '18:00'),
(50, 'Surat ', 'Rajkot', 'sleeper', '580', '21:00'),
(51, 'Vadodara', 'Ahemdabad', 'seater', '150', '21:00'),
(52, 'Vadodara', 'Ahemdabad', 'sleeper', '280', '22:00'),
(53, 'Vadodara', 'Gandhinagar', 'seater', '200', '21:00'),
(54, 'Vadodara', 'Gandhinagar', 'sleeper', '310', '22:00'),
(55, 'Vadodara', 'Surat', 'seater', '130', '08::00'),
(56, 'Vadodara', 'Surat', 'sleeper', '220', '20:00'),
(57, 'Vadodara', 'Junagadh', 'seater', '430', '17:00'),
(58, 'Vadodara', 'Junagadh', 'sleeper', '600', '18:00'),
(59, 'Vadodara', 'Rajkot', 'seater', '380', '17:00'),
(60, 'Vadodara', 'Rajkot', 'sleeper', '500', '18:00'),
(61, 'junagadh', 'rajkot', 'seater', '120', '09:00'),
(63, 'Junagadh', 'Ahemdabad', 'Seater', '300', '20:00'),
(74, 'Surat', 'Rajkot', 'Seater', '320', '19:00');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_pay`
--

CREATE TABLE `ticket_pay` (
  `id` int(11) NOT NULL,
  `cardnumber` varchar(12) NOT NULL,
  `pin` varchar(6) NOT NULL,
  `price` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket_pay`
--

INSERT INTO `ticket_pay` (`id`, `cardnumber`, `pin`, `price`) VALUES
(1, '123456789012', '1245', '300'),
(2, '123456789012', '1245', '300'),
(3, '123456789012', '1245', '300'),
(4, '123456789012', '1245', '300'),
(5, '123456789012', '1245', '300'),
(6, '123456789012', '1245', '50'),
(7, '123456789012', '1245', '400'),
(8, '123456789012', '1244', '60'),
(9, '123456789012', '6546', '150'),
(10, '123456789012', '9090', '380'),
(11, '123456789012', '9090', '380'),
(12, '838475675812', '9098', '380'),
(13, '123456789012', '6546', '380'),
(14, '838475675812', '1234', '380');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `number`, `email`, `password`, `gender`, `dob`) VALUES
(1, 'user', '654333243', 'user@gmail.com', 'u4user', 'M', '02-02-2005'),
(2, 'max star', '8765456765', 'max@gmail.com', 'm123', 'M', '11-09-2008'),
(9, 'lio', '9878787860', 'lio@gmail.com', 'lio123', 'M', '1992-05-04'),
(11, 'Jiya Raiz', '7656565656', 'jiya@gmail.com', 'j123', 'F', '2000-02-29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fullseat_bookings`
--
ALTER TABLE `fullseat_bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fullsleep_bookings`
--
ALTER TABLE `fullsleep_bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket_pay`
--
ALTER TABLE `ticket_pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fullseat_bookings`
--
ALTER TABLE `fullseat_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fullsleep_bookings`
--
ALTER TABLE `fullsleep_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `ticket_pay`
--
ALTER TABLE `ticket_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
