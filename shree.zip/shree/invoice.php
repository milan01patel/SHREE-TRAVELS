<?php 
include('db.php');
?>
<?php 
      $select=mysqli_query($con,"SELECT * FROM `bookings`");
      $row=mysqli_fetch_array($select);
?>


<?php
if(isset($_GET['id']))
{
  $id= $_GET['id'];}
  $query="select * from `bookings` where `id`='$id'";
      $result= mysqli_query($con,$query);

     if(!$result)
      {
        echo("query failed".mysqli_error());
      }
      else
      {
        $row=mysqli_fetch_assoc($result); 
      } 
?>

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Ticket</title>
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="bootstrap_min.css" type="text/css">
    <link rel="stylesheet" href="font.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .ticket {
            border: 2px dashed #333;
            padding: 20px;
            margin: 20px auto;
            max-width: 600px;
        }
        .ticket-header, .ticket-footer {
            text-align: center;
            margin-bottom: 20px;
        }
       
    </style>
</head>
<body style="background-color:rgba(255, 255, 205, 0.500);">
    <div class="ticket" style="background-color:rgba(255, 255, 205, 0.805);">
        <div class="ticket-header">
            <h2 style="font-family:fantasy;">S H R E E &nbsp; T R A V E L S</h2>
            <h3> TICKET</h3>
            <h5><u><strong>BOOKID : </strong><?php echo $row['bookid'];?> </u></h5>
            
        </div>
        <div class="mt-4">
            <h5><strong class="ml-5">NAME : </strong> <?php echo $row['firstname'];?></h5>
            <h5><strong class="ml-5">SOURCE : </strong><?php echo $row['source'];?> <strong class="ml-5">DESTINATION : </strong><?php echo $row['destination'];?></h5>
            <h5><strong class="ml-5">TYPE : </strong><?php echo $row['type'];?> </h5>
            <h5><strong class="ml-5">DATE : </strong><?php echo $row['date'];?><strong class="ml-5">&nbsp;&nbsp;&nbsp;TIME : </strong><?php echo $row['time'];?> </p>
            <br>
            <center style="font-family:papyrus;">"Have A Safe And Memorable Journey With Us. <br> Happy Journey ☺"</center>
        </div>
    </div>
</body>
</html>
