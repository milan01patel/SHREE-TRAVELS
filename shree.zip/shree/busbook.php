<?php include('header.php'); ?>
<br>  
<div class="container">  
<button type="button" class="btn"><a href="index.php"><img src="img/home.png"></a><br>HOME</button>
<button type="button" class="btn"><a href="profile.php"><img src="img/profile.png"></a><br>PROFILE</button>
</div>

<!-- ----------------------------find your route---------------------------------- -->
<div class="col text-center ">
    <a href="SCHEDULE.PHP" class="btn btn-outline-danger rounded-pill"  role="button" aria-disabled="true">F I N D & B O O K</a>
    </div>

<!-----------------------------many options------------------------------------>
<div class="container text-center mt-5">
  <div class="row " >
    <div class="col">
    <p class=" bg-light rounded-pill text-danger font-monospace">✧ FIND YOURE ROUTE IN LIST & BOOK TICKET ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="schedule.php"> <img src="img/inlist.png" alt=""></a><br>FIND & BOOK</button>
    </div>
    <div class="col">
    <p class="bg-light rounded-pill text-danger font-monospace">✧ FOR BOOK FULL BUS ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="fullbook.php"> <img src="img/book2.png" alt=""></a><br>BOOK BUS</button>
    </div>
    <div class="col">
    <p class="bg-light rounded-pill text-danger font-monospace">✧ GET BOOKING INFORMATION ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="mybooking.php"> <img src="img/ubook.png" alt=""></a><br>BOOKING INFO</button>
    </div>   
    
  </div>
</div>
<div class="container text-center mt-5">
  <div class="row" >
    <div class="col">
    <p class=" bg-light rounded-pill text-danger font-monospace">✧ SHOW ALL VIEW OF SEATS (BUS VIEW)  ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="bus-set.php"> <img src="img/bus-set1.png" alt=""></a><br>V I E W GALLARY</button>
    </div>
 
  </div>
</div>