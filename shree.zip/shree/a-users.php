<?php 
include('header.php');
include('db.php');
//  $query="select *from users" ;
//  $result=mysqli_query($con,$query); 
$query = "select * from users";  
$run = mysqli_query($con,$query);  
?>
<!-- *************** back button ****************** -->
<div class="container">
<button type="button" class="btn"><a href="allinfo.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- ***************************search******************************* -->
<div class="container mt-5 btn-lg text-end text-danger">
    <b >serach user using email -></b>
	<input type="text" placeholder="user email..." id="myInput" onkeyup="myFunction()" name="search" class="bg-dark text-light rounded ">
	<i class="fa-solid fa-magnifying-glass animate__animated animate__fadeInTopRight"></i>
</div>
<!-- **************************user data******************************* -->
<div class="container mt-1 ">
<table  class="table table-striped table-warning text-center" id="myTable">  
      <tr  class="bg-dark text-danger fs-5">  
           <th>Uid</th>  
           <th>Name</th>  
           <th>Number</th>  
           <th>Email</th>  
           <th>Gender</th>  
           <th>Dob</th>  
           <th>Ban User</th>    
      </tr>  
      <?php    
           if ($num = mysqli_num_rows($run)>0) {  
                while ($result = mysqli_fetch_assoc($run)) {  
                    echo"<tr>
                            <td>".$result['uid']."</td>
                            <td>".$result['name']."</td>
                            <td>".$result['number']."</td>
                            <td>".$result['email']."</td>
                            <td>".$result['gender']."</td>
                            <td>".$result['dob']."</td>
                            <td><a  href='a-delete.php?uid=".$result['uid']."' class='btn btn-outline-danger'><b>Delete</b></a></td>
                        </tr>";
                }
           }
      ?>
 </table>
</div>

   <!-- search & sorting javascript -->
   <script>
	function myFunction() 
	{
  		var input, filter, table, tr, td, i, txtValue;
  		input = document.getElementById("myInput");
  		filter = input.value.toUpperCase();
  		table = document.getElementById("myTable");
  		tr = table.getElementsByTagName("tr");
  	for (i = 1; i < tr.length; i++) 
	{
    	td = tr[i].getElementsByTagName("td")[3];
    	if (td) 
		{
      	txtValue = td.textContent || td.innerText;
      	if (txtValue.toUpperCase().indexOf(filter) > -1)
		{
        	tr[i].style.display = "";
      	} 
		else 
		{
        	tr[i].style.display = "none";
      	}
    }       
  }
}
</script>