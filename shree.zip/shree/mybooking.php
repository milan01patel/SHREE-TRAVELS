<?php
    include("header.php");
?>
  <!-- *************** back button ****************** -->
  <div class="container">
<button type="button" class="btn"><a href="busbook.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- ************************************************** -->
<div class="container text-center mt-5">
  <div class="row " >
    <div class="col">
    <p class=" bg-light rounded-pill text-danger font-monospace">✧ TICKET BOOKINGS ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="myticket.php"> <img src="img/book1.png" alt=""></a></button>
    </div>
    <div class="col">
    <p class="bg-light rounded-pill text-danger font-monospace">✧ FULL SEATER BOOKINGS ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="myfull.php"> <img src="img/book2.png" alt=""></a></button>
    </div>
    <div class="col">
    <p class="bg-light rounded-pill text-danger font-monospace">✧ FULL SLEEPER BOOKINGS ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="myfull.php"> <img src="img/full.png" alt=""></a></button>
    </div>
  </div>
</div>