<html lang="en"><head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>USER AGREEMENT - ConfirmTkt</title>
  <style>
    body {
      font-size: 14px;
      font-family: "Roboto", sans-serif;
      max-width: 800px;
      color: #777;
      background-color:FFF8DC;
      padding: 16px;
      margin: 0;
      line-height: 1.6;
    }

    li {
      padding: 8px 0;
      line-height: inherit;
    }

    ol {
      padding: 0 10px 0 30px;
    }

    a {
      color: #42a047;
    }

    @media screen and (min-width: 768px) {
      body {
        margin: 2rem auto;
        border: solid 1px #ccc;
        padding: 1rem;
      }

      br {
        display: none;
      }
    }

    h1 {
      font-size: 20px;
      color: #333;
    }

    h2 {
      font-size: 14px;
    }

    a {
      margin-inline: 4px;
    }

    hr {
      border: #eaeaea;
    }

    a {
      display: inline;
      word-wrap: break-word;
    }
  </style>
</head>

<body>
  <!-- *************** back button ****************** -->
 <div class="container">
<button type="button" class="btn"><a href="index.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- ********************************** -->
  <h1><b> USER AGREEMENT </b></h1>
  <hr>
  <section>
    <h2><b>TERMS OF USE</b></h2>
    <p> These Terms of Use along with Terms of Service (collectively, the “<b>User Agreement</b>“) constitute a legally
      binding agreement made between you, whether personally or on behalf of an entity (“You/User”) and Le Travenues
      Technology Limited (“Travenues”), a travel technology company incorporated and existing in India in accordance
      with the Companies Act, 1956, concerning your access to and use of the Confirmtkt.com website as well as mobile
      application related, linked, or otherwise connected thereto (collectively, the “Site”). </p>
  </section>
  <p><b>confirmtkt.com</b>is a travel website owned and operated by Travenues, hereinafter referred to as (“Confirmtkt”/
    “we”/ “us” or “our”).</p>
  <p>You agree that by accessing the site, you have read, understood, and agree to be bound by all of these Terms of
    Use. If you do not agree with all of these Terms of Use, then you are expressly prohibited from using the Site and
    you must discontinue use immediately.</p>
  <p>Supplemental terms and conditions or documents that may be posted on the site from time to time are hereby
    expressly incorporated herein by reference. We reserve the right, in our sole discretion, to make changes or
    modifications to this User Agreement at any time and for any reason.</p>
  <p>We will alert you about any changes by updating the “Last updated” date of these Terms of Use, and you waive any
    right to receive specific notice of each such change.</p>
  <p>It is your responsibility to periodically review these Terms of Use to stay informed of updates. You will be
    subject to and will be deemed to have been made aware of and to have accepted, the changes in any revised Terms of
    Use by your continued use of the Site after the date such revised Terms of Use are posted. </p>
  <p>The information provided on the Site is not intended for distribution to or use by any person or entity in any
    jurisdiction or country where such distribution or use would be contrary to law or regulation or which would subject
    us to any registration requirement within such jurisdiction or country.</p>
  <p>Accordingly, those persons who choose to access the site from other locations do so on their own initiative and are
    solely responsible for compliance with local laws, if and to the extent local laws are applicable.</p>
  <section>
    <h2><b>ELIGIBILITY</b></h2>
    <p>The site is intended for users who are at least 18 years old. Persons under the age of 18 are not permitted to
      register for the site. If you are a minor, you must have your parent or guardian read and agree to these Terms of
      Use prior to you using the site.</p>
  </section>
  <section>
    <h2><b>INTELLECTUAL PROPERTY RIGHTS</b></h2>
    <p>Unless otherwise indicated, the site is our proprietary property and all source code, databases, functionality,
      software, website designs, audio, video, text, photographs, and graphics on the site (collectively, the “Content”)
      and the trademarks, service marks, and logos contained therein (the “Marks”) are owned or controlled by us or
      licensed to us, and are protected by copyright and trademark laws and various other intellectual property rights
      and unfair competition laws of the United States, foreign jurisdictions, and international conventions.</p>
    <p>The Content and the Marks are provided on the Site “AS IS” for your information and personal use only. Except as
      expressly provided in these Terms of Use, no part of the site and no Content or Marks may be copied, reproduced,
      aggregated, republished, uploaded, posted, publicly displayed, encoded, translated, transmitted, distributed,
      sold, licensed, or otherwise exploited for any commercial purpose whatsoever, without our express prior written
      permission.</p>
    <p>Provided that You are eligible to use the Site, you are granted a limited license to access and use the Site and
      to download or print a copy of any portion of the Content to which you have properly gained access solely for your
      personal, non-commercial use. We reserve all rights not expressly granted to you in and to the site, the Content
      and the Marks.</p>
  </section>
  <section>
    <h2><b>USER REPRESENTATIONS</b></h2>
    <p>By using the site, you represent and warrant that:</p>
    <ol start="1" type="1">
      <li>All registration information you submit will be true, accurate, current, and complete. </li>
      <li>You will maintain the accuracy of such information and promptly update such registration information as
        necessary.</li>
      <li>You have the legal capacity, and you agree to comply with this User Agreement;</li>
      <li>You are not under the age of 18;</li>
      <li>not a minor in the jurisdiction in which you reside, or if a minor, you have received parental permission to
        use the Site;</li>
      <li>you will not access the Site through automated or non-human means, whether through a bot, script, or
        otherwise;</li>
      <li>You will not use the Site for any illegal or unauthorized purpose;</li>
      <li>Your use of the Site will not violate any applicable law or regulation.</li>
    </ol>
    <p>If you provide any information that is untrue, inaccurate, not current, or incomplete, we have the right to
      suspend or terminate your account and refuse any and all current or future use of the Site (or any portion
      thereof).</p>
  </section>
  <section>
    <h2><b>USER REGISTRATION</b></h2>
    <p>You may be required to register with the Site. You agree to keep your password confidential and will be
      responsible for all use of your account and password. We reserve the right to remove, reclaim, or change a
      username you select if we determine, in our sole discretion, that such username is inappropriate, obscene, or
      otherwise objectionable or we have reason to believe that password might have compromised to any external threat.
    </p>
  </section>
  <section>
    <p><b>FRAUDULENT ACTIVITIES, FAKE CALLS &amp; SCAMS</b></p>
    <p>Confirmtkt employees or representatives will never ask for any personal information like credit/debit card
      number, CVV, OTP, card expiry date, user IDs, passwords, etc. Also, you will never be asked to install any
      third-party applications that grant access to your mobile or computer screen.Beware of anyone who is claiming to
      be associated with Confirmtkt. Acting on any such requests may make you a victim of fraud, potentially leading to
      the loss of valuable information or money.</p>
  </section>
  <section>
    <p><b>PROHIBITED ACTIVITIES</b></p>
    <p>You may not access or use the Site for any purpose other than that for which we make the Site available. The Site
      may not be used in connection with any commercial endeavors except those that are specifically endorsed or
      approved by us.</p>
    <p>As a User of the Site, you agree not to:</p>
    <ol start="1" type="1">
      <li>systematically retrieve data or other content from the Site to create or compile, directly or indirectly, a
        collection, compilation, database, or directory without written permission from us. </li>
      <li>make any unauthorized use of the Site, including collecting usernames and/or email addresses of users by
        electronic or other means for the purpose of sending unsolicited email, or creating user accounts by automated
        means or under false pretenses.</li>
      <li>use a buying agent or purchasing agent to make purchases on the Site.</li>
      <li>use the Site to advertise or offer to sell goods and services.</li>
      <li>circumvent, disable, or otherwise interfere with security-related features of the Site, including features
        that prevent or restrict the use or copying of any Content or enforce limitations on the use of the Site and/or
        the Content contained therein.</li>
      <li>engage in unauthorized framing of or linking to the Site.</li>
      <li>trick, defraud, or mislead us and other Users, especially in any attempt to learn sensitive account
        information such as User passwords;</li>
      <li>make improper use of our support services or submit false reports of abuse or misconduct. </li>
      <li>engage in any automated use of the system, such as using scripts to send comments or messages, or using any
        data mining, robots, or similar data gathering and extraction tools.</li>
      <li>interfere with, disrupt, or create an undue burden on the Site or the networks or services connected to the
        Site.</li>
      <li>attempt to impersonate another User or person or use the username of another User.</li>
      <li>sell or otherwise transfer your profile.</li>
      <li>use any information obtained from the Site in order to harass, abuse, or harm another person.</li>
      <li>use the Site as part of any effort to compete with us or otherwise use the Site and/or the Content for any
        revenue-generating endeavor or commercial enterprise.</li>
      <li>decipher, decompile, disassemble, or reverse engineer any of the software comprising or in any way making up a
        part of the Site.</li>
      <li>attempt to bypass any measures of the Site designed to prevent or restrict access to the Site, or any portion
        of the Site.</li>
      <li>harass, annoy, intimidate, or threaten any of our employees or agents engaged in providing any portion of the
        Site to you.</li>
      <li>delete the copyright or other proprietary rights notice from any Content. </li>
      <li>copy or adapt the Site’s software, including but not limited to Flash, PHP, HTML, JavaScript, or other code.
      </li>
      <li>upload or transmit (or attempt to upload or to transmit) viruses, Trojan horses, or other material, including
        excessive use of capital letters and spamming (continuous posting of repetitive text), that interferes with any
        party’s uninterrupted use and enjoyment of the Site or modifies, impairs, disrupts, alters, or interferes with
        the use, features, functions, operation, or maintenance of the Site.</li>
      <li>upload or transmit (or attempt to upload or transmit) any material that acts as a passive or active
        information collection or transmission mechanism, including without limitation, clear graphics interchange
        formats (“gifs”), 1×1 pixels, web bugs, cookies, or other similar devices (sometimes referred to as “spyware” or
        “passive collection mechanisms” or “pcms”).</li>
      <li>except as may be the result of standard search engine or Internet browser usage, use, launch, develop, or
        distribute any automated system, including without limitation, any spider, robot, cheat utility, scraper, or
        offline reader that accesses the Site, or using or launching any unauthorized script or other software.</li>
      <li>disparage, tarnish, or otherwise harm, in our opinion, us and/or the Site. </li>
      <li>use the Site in a manner inconsistent with any applicable laws or regulations.</li>
    </ol>
  </section>
  <section>
    <p><b>USER GENERATED CONTRIBUTIONS</b></p>
    <p>The Site may invite you to chat, contribute to, or participate in blogs, message boards, online forums, and other
      functionality, and may provide you with the opportunity to create, submit, post, display, transmit, perform,
      publish, distribute, or broadcast content and materials to us or on the Site, including but not limited to text,
      writings, video, audio, photographs, graphics, comments, suggestions, or personal information or other material
      (collectively, “Contributions”).</p>
    <p>Contributions may be viewable by other Users of the Site and through third-party websites. As such, any
      Contributions you transmit may be treated as non-confidential and non-proprietary. When you create or make
      available any Contributions, you thereby represent and warrant that:</p>
    <ol start="1" type="1">
      <li>the creation, distribution, transmission, public display, or performance, and the accessing, downloading, or
        copying of your contributions do not and will not infringe the proprietary rights, including but not limited to
        the copyright, patent, trademark, trade secret, or moral rights of any third party.</li>
      <li>you are the creator and owner of or have the necessary licenses, rights, consents, releases, and permissions
        to use and to authorize us, the site, and other users of the Site to use your Contributions in any manner
        contemplated by the Site and these Terms of Use.</li>
      <li>you have the written consent, release, and/or permission of each and every identifiable individual person in
        your Contributions to use the name or likeness of each and every such identifiable individual person to enable
        inclusion and use of your Contributions in any manner contemplated by the Site and these Terms of Use.</li>
      <li>your Contributions are not false, inaccurate, or misleading.</li>
      <li>your Contributions are not unsolicited or unauthorized advertising, promotional materials, pyramid schemes,
        chain letters, spam, mass mailings, or other forms of solicitation.</li>
      <li>your Contributions are not obscene, lewd, lascivious, filthy, violent, harassing, libelous, slanderous, or
        otherwise objectionable (as determined by us).</li>
      <li>your Contributions do not ridicule, mock, disparage, intimidate, or abuse anyone.</li>
      <li>your Contributions do not violate any applicable law, regulation, or rule. </li>
      <li>your Contributions do not violate the privacy or publicity rights of any third party.</li>
      <li>your Contributions do not include any offensive comments that are connected to race, national origin, gender,
        sexual preference, or physical handicap.</li>
      <li>your Contributions do not otherwise violate, or link to material that violates, any provision of these Terms
        of Use, or any applicable law or regulation.</li>
    </ol>
    <p>Any use of the Site in violation of the foregoing violates these Terms of Use and may result in, among other
      things, termination or suspension of your rights to use the Site.</p>
  </section>
  <section>
    <p><b>CONTRIBUTION LICENSE</b></p>
    <p>By posting your Contributions to any part of the Site or making Contributions accessible to the Site by linking
      your account from the Site to any of your social networking accounts, you automatically grant, and you represent
      and warrant that you have the right to grant, to us an unrestricted, unlimited, irrevocable, perpetual,
      non-exclusive, transferable, royalty-free, fully-paid, worldwide right, and license to host, use, copy, reproduce,
      disclose, sell, resell, publish, broadcast, retitle, archive, store, cache, publicly perform, publicly display,
      reformat, translate, transmit, excerpt (in whole or in part), and distribute such Contributions (including,
      without limitation, your image and voice) for any purpose, commercial, advertising, or otherwise, and to prepare
      derivative works of, or incorporate into other works, such Contributions, and grant and authorize sublicenses of
      the foregoing. The use and distribution may occur in any media formats and through any media channels.</p>
    <p>This license will apply to any form, media, or technology now known or hereafter developed, and includes our use
      of your name, company name, and franchise name, as applicable, and any of the trademarks, service marks, trade
      names, logos, and personal and commercial images you provide. You waive all moral rights in your Contributions,
      and you warrant that moral rights have not otherwise been asserted in your Contributions. </p>
    <p>We do not assert any ownership over your Contributions. You retain full ownership of all of your Contributions
      and any intellectual property rights or other proprietary rights associated with your Contributions. We are not
      liable for any statements or representations in your Contributions provided by you in any area on the Site.</p>
    <p>You are solely responsible for your Contributions to the Site and you expressly agree to exonerate us from any
      and all responsibility and to refrain from any legal action against us regarding your Contributions.</p>
    <p>We have the right, in our sole and absolute discretion, (1) to edit, redact, or otherwise change any
      Contributions; (2) to re-categorize any Contributions to place them in more appropriate locations on the Site; and
      (3) to pre-screen or delete any Contributions at any time and for any reason, without notice. We have no
      obligation to monitor your Contributions.</p>
  </section>
  <section>
    <p><b>GUIDELINES FOR REVIEWS</b></p>
    <p>We may provide you areas on the Site to leave reviews or ratings. When posting a review, you must comply with the
      following criteria:</p>
    <ol start="1" type="1">
      <li>you should have firsthand experience with the person/entity being reviewed </li>
      <li>your reviews should not contain offensive profanity, or abusive, racist, offensive, or hate language</li>
      <li>your reviews should not contain discriminatory references based on religion, race, gender, national origin,
        age, marital status, sexual orientation, or disability;</li>
      <li>your reviews should not contain references to illegal activity;</li>
      <li>you should not be affiliated with competitors if posting negative reviews; </li>
      <li>you should not make any conclusions as to the legality of conduct;</li>
      <li>you may not post any false or misleading statements;</li>
      <li>you may not organize a campaign encouraging others to post reviews, whether positive or negative.</li>
    </ol>
    <p>We may accept, reject, or remove reviews in our sole discretion. We have absolutely no obligation to screen
      reviews or to delete reviews, even if anyone considers reviews objectionable or inaccurate. Reviews are not
      endorsed by us, and do not necessarily represent our opinions or the views of any of our affiliates or partners.
    </p>
    <p>We do not assume liability for any review or for any claims, liabilities, or losses resulting from any review. By
      posting a review, you hereby grant to us a perpetual, non-exclusive, worldwide, royalty-free, fully paid,
      assignable, and sublicensable right and license to reproduce, modify, translate, transmit by any means, display,
      perform, and/or distribute all content relating to reviews.</p>
  </section>
  
  <section>
    <h3><b>Apple and Android Devices</b></h3>
    <p>The following terms apply when you use a mobile application obtained from either the Apple Store or Google Play
      Store (each an “App Distributor”) to access the Site:</p>
    <p>(1) the license granted to you for our mobile application is limited to a non-transferable license to use the
      application on a device that utilizes the Apple iOS or Android operating systems, as applicable, and in accordance
      with the usage rules set forth in the applicable App Distributor’s terms of service;</p>
    <p>(2) we are responsible for providing any maintenance and support services with respect to the mobile application
      as specified in the terms and conditions of this mobile application license contained in these Terms of Use or as
      otherwise required under applicable law, and you acknowledge that each App Distributor has no obligation
      whatsoever to furnish any maintenance and support services with respect to the mobile application;</p>
    <p>(3) you acknowledge and agree that the App Distributors are third-party beneficiaries of the terms and conditions
      in this mobile application license contained in these Terms of Use, and that each App Distributor will have the
      right (and will be deemed to have accepted the right) to enforce the terms and conditions in this mobile
      application license contained in these Terms of Use against you as a third-party beneficiary thereof.</p>
  </section>
  <section>
    <h2><b>SOCIAL MEDIA</b></h2>
    <p>As part of the functionality of the Site, you may link your account with online accounts you have with
      third-party service providers (each such account, a “Third-Party Account”) by either: (1) providing your
      Third-Party Account login information through the Site; or (2) allowing us to access your Third-Party Account, as
      is permitted under the applicable terms and conditions that govern your use of each Third-Party Account.</p>
    <p>You represent and warrant that you are entitled to disclose your Third-Party Account login information to us
      and/or grant us access to your Third-Party Account, without breach by you of any of the terms and conditions that
      govern your use of the applicable Third-Party Account, and without obligating us to pay any fees or making us
      subject to any usage limitations imposed by the third-party service provider of the Third-Party Account.</p>
    <p>By granting us access to any Third-Party Accounts, you understand that (1) we may access, make available, and
      store (if applicable) any content that you have provided to and stored in your Third-Party Account (the “Social
      Network Content”) so that it is available on and through the Site via your account, including without limitation
      any friend lists and (2) we may submit to and receive from your Third-Party Account additional information to the
      extent you are notified when you link your account with the Third-Party Account. </p>
    <p>Depending on the Third-Party Accounts you choose and subject to the privacy settings that you have set in such
      Third-Party Accounts, personally identifiable information that you post to your Third-Party Accounts may be
      available on and through your account on the Site.</p>
    <p>Please note that if a Third-Party Account or associated service becomes unavailable or our access to such
      Third-Party Account is terminated by the third-party service provider, then Social Network Content may no longer
      be available on and through the Site. You will have the ability to disable the connection between your account on
      the Site and your Third-Party Accounts at any time.</p>
    <p>PLEASE NOTE THAT YOUR RELATIONSHIP WITH THE THIRD-PARTY SERVICE PROVIDERS ASSOCIATED WITH YOUR THIRD-PARTY
      ACCOUNTS IS GOVERNED SOLELY BY YOUR AGREEMENT(S) WITH SUCH THIRD-PARTY SERVICE PROVIDERS. </p>
    <p>We make no effort to review any Social Network Content for any purpose, including but not limited to, for
      accuracy, legality, or non-infringement, and we are not responsible for any Social Network Content.</p>
    <p>You acknowledge and agree that we may access your email address book associated with a Third-Party Account and
      your contacts list stored on your mobile device or tablet computer solely for purposes of identifying and
      informing you of those contacts who have also registered to use the Site.</p>
    <p>You can deactivate the connection between the Site and your Third-Party Account by contacting us using the
      contact information below or through your account settings (if applicable). We will attempt to delete any
      information stored on our servers that was obtained through such Third-Party Accounts, except the username and
      profile picture that become associated with your account.</p>
  </section>
  
  
  <section>
    <h2><b>SITE MANAGEMENT</b></h2>
    <p>We reserve the right, but not the obligation, to:</p>
    <p>(1) monitor the Site for violations of these Terms of Use;</p>
    <p>(2) take appropriate legal action against anyone who, in our sole discretion, violates the law or these Terms of
      Use, including without limitation, reporting such User to law enforcement authorities; </p>
    <p>(3) in our sole discretion and without limitation, refuse, restrict access to, limit the availability of, or
      disable (to the extent technologically feasible) any of your Contributions or any portion thereof;</p>
    <p>(4) inour sole discretion and without limitation, notice, or liability, to remove from the Site or otherwise
      disable all files and content that are excessive in size or are in any way burdensome to our systems;</p>
    <p>(5) otherwise manage the Site in a manner designed to protect our rights and property and to facilitate the
      proper functioning of the Site.</p>
  </section>
  <section>
    <h2><b>PRIVACY POLICY</b></h2>
    <p>We care about data privacy and security. Please review our<a href="http://ixigo.com/about/more-info/privacy/">Privacy Policy</a>here to learn more about how we collect and
      use information about User via our Site. By using the Site, you agree to be bound by our Privacy Policy, which is
      incorporated into these Terms of Use.</p>
    <p>We do not knowingly accept, request, or solicit information from children or knowingly market to children. If we
      receive actual knowledge that anyone under the age of 13 has provided personal information to us without the
      requisite and verifiable parental consent, we will delete that information from the Site as quickly as is
      reasonably practical.</p>
  </section>
  <section>
    <h2><b>INTELLECTUAL PROPERTY RIGHTS INFRINGEMENTS</b></h2>
    <p>We respect the intellectual property rights of others. If you believe that any material available on or through
      the Site infringes upon any Intellectual Property Rights (“IPR”) you own or control, please immediately notify us
      at<a href="mailto:legal@confirmtkt.com">legal@confirmtkt.com</a>. A copy of your notification will be sent to the
      person who posted or stored the material addressed in the notification.</p>
    <p>Please be advised that pursuant to applicable law you may be held liable for damages if you make material
      misrepresentations in your notification. Thus, if you are not sure that material located on or linked to by the
      Site infringes your IPR, you should consider first contacting an attorney.</p>
  </section>
  <section>
    <h2><b>FEES AND PAYMENTS</b></h2>
    <p>Over and above booking charges for the products/ services offered on the Site, Confirmtkt may charge certain fees
      in the nature of convenience fees, service fees, payment gateway charges (“Additional Fees”) for making services
      conveniently available to User online. Confirmtkt further reserves the right to alter any and all fees from time
      to time without prior notice to the User. Any such Additional Fees will be displayed to the User before confirming
      the booking or collecting the payment to enable you to make an informed choice. </p>
    <p>The User is responsible for payment of all charges, fees, duties, taxes, and assessments resulting out of the use
      of the Site, as per the applicable laws. In cases where booking amount, taxes, statutory fee, service fees,
      convenience fee, payment gateway charges etc. are not properly charged or undercharged (“Balance Amount”), owing
      to any technical error or other reason, Confirmtkt reserves the right to deduct, charge or claim the Balance
      Amount from the User and the User shall pay such Balance Amount to Confirmtkt. In cases where such Balance Amount
      is claimed prior to the utilization of the booking, Confirmtkt will be at liberty to cancel such bookings if the
      amount is not paid before the utilization date.</p>
    <p>In the event there is any addition in the prices charged by us as a result of change in applicable law including
      but not limited to, changes in tax rates or imposition of new taxes, or levies by Government, such increased
      charge will have to be borne by the User. Confirmtkt may introduce such additional charges without prior notice to
      the User and could also be retrospective, but will always be as per applicable law.</p>
    <p>In the rare event of a booking not getting confirmed for any reason whatsoever, Confirmtkt shall not be liable to
      offer an alternate booking in lieu of or to compensate for the unconfirmed booking. Any succeeding booking will be
      regarded as a new transaction. The pertinent refund will be processed to the User as per the relevant policies of
      the third party and Confirmtkt as the case may be.</p>
    <p>No communication will ever be made by us or any of our employees or authorized representatives enquiring about a
      User’s credit or debit card number, expiry date, CVV, net banking login, passwords, OTP, request for a fund
      transfer to a personal or an individual bank account, installation of any third-party applications that enable
      them to view a User’s mobile or computer screen. Acting on any of these requests may make you a victim of fraud
      and may potentially lead to loss of your valuable money or information. </p>
    <p>Please be advised to not share your personal sensitive information like credit/debit card number, CVV, OTP, card
      expiry date, user IDs, passwords etc. with any person including the agents, employees or representatives of
      Confirmtkt. If any such details are requested by any of our agents, employees or representatives, please inform us
      at the earliest on the contact details mentioned below. However, Confirmtkt shall not be liable for any loss that
      the User incurs for sharing the aforesaid details.</p>
    <p>All booking(s) made on the Site are subject to the applicable cancellation policy made visible and communicated
      to the Users on the Site in writing. The applicable refunds on cancelled bookings will be processed to the
      relevant User account either by way of wallet transfer or reversed to same banking instrument (credit card, debit
      card, Bank account, wallet etc.) from which initial payment was made. </p>
  </section>
  <section>
    <h2><b>INSURANCE</b></h2>
    <p>Unless explicitly provided by Confirmtkt in any specific service or deliverable, obtaining sufficient insurance
      coverage is the obligation of the User. In no case Confirmtkt shall accept any claims arising out of such
      scenarios.</p>
    <p>Insurance, if any provided as a part of the service or product by Confirmtkt shall be as per the terms and
      conditions of the third-party insurance company. Confirmtkt merely acts as a facilitator in connecting the User
      with insurance company. The User shall contact the insurance company directly for any claims or disputes.
      Confirmtkt shall not be held liable in case of partial acceptance or denial of the claims by the insurance
      company.</p>
  </section>
  <section>
    <p><b>TERM AND TERMINATION</b></p>
    <p>This User Agreement shall remain in full force and effect while you use the Site. WITHOUT LIMITING ANY OTHER
      PROVISION OF THIS USER AGREEMENT, WE RESERVE THE RIGHT TO, IN OUR SOLE DISCRETION AND WITHOUT NOTICE OR LIABILITY,
      DENY ACCESS TO AND USE OF THE SITE (INCLUDING BLOCKING CERTAIN IP ADDRESSES), TO ANY PERSON FOR ANY REASON OR FOR
      NO REASON, INCLUDING WITHOUT LIMITATION FOR BREACH OF ANY REPRESENTATION, WARRANTY, OR COVENANT CONTAINED IN THIS
      USER AGREEMENT OR OF ANY APPLICABLE LAW OR REGULATION. WE MAY TERMINATE YOUR USE OR PARTICIPATION IN THE SITE OR
      DELETE YOUR ACCOUNT AND ANY CONTENT OR INFORMATION THAT YOU POSTED AT ANY TIME, WITHOUT WARNING, IN OUR SOLE
      DISCRETION.</p>
    <p>If we terminate or suspend your account for any reason, you are prohibited from registering and creating a new
      account under your name, a fake or borrowed name, or the name of any third party, even if you may be acting on
      behalf of the third party.</p>
    <p>In addition to terminating or suspending your account, we reserve the right to take appropriate legal action,
      including without limitation pursuing civil, criminal, and injunctive redress.</p>
  </section>
  <section>
    <h2><b>MODIFICATIONS AND INTERRUPTIONS</b></h2>
    <p>We reserve the right to change, modify, or remove the contents of the Site at any time or for any reason at our
      sole discretion without notice. However, we have no obligation to update any information on our Site. We also
      reserve the right to modify or discontinue all or part of the Site without notice at any time. </p>
    <p>We will not be liable to you or any third party for any modification, price change, suspension, or discontinuance
      of the Site.</p>
    <p>We cannot guarantee the Site will be available at all times. We may experience hardware, software, or other
      problems or need to perform maintenance related to the Site, resulting in interruptions, delays, or errors.</p>
    <p>We reserve the right to change, revise, update, suspend, discontinue, or otherwise modify the Site at any time or
      for any reason without notice. You agree that we have no liability whatsoever for any loss, damage, or
      inconvenience caused by your inability to access or use the Site during any downtime or discontinuance of the
      Site.</p>
    <p>Nothing in these Terms of Use will be construed to obligate us to maintain and support the Site or to supply any
      corrections, updates, or releases in connection therewith.</p>
  </section>
  <section>
    <h2><b>GOVERNING LAW</b></h2>
    <p> This User Agreement and your use of the Site are governed by and construed in accordance with the laws of India
      and the Parties shall refer any unresolved disputes to the exclusive jurisdiction of courts in Bangalore.<b></b>
    </p>
  </section>
  <section>
    <h2><b>CORRECTIONS</b></h2>
    <p>There may be information on the Site that contains typographical errors, inaccuracies, or omissions that may
      relate to the Site, including descriptions, pricing, availability, and various other information. We reserve the
      right to correct any errors, inaccuracies, or omissions and to change or update the information on the Site at any
      time, without prior notice.</p>
  </section>
  <section>
    <h2><b>LIMITATIONS OF LIABILITY</b></h2>
    <p>Unless Confirmtkt explicitly acts as a reseller in certain scenarios, Confirmtkt always acts as a facilitator by
      connecting the Customer with the respective service providers like Railway, airlines, hotels,bus operators etc.
      Confirmtkt ’s liability is limited to providing the Customer with a confirmed booking as selected by the Customer.
    </p>
    <p>Any issues or concerns faced by the Customer at the time of availing any such services shall be the sole
      responsibility of the service provider. Confirmtkt will have no liability with respect to the acts, omissions,
      errors, representations, warranties, breaches or negligence on the part of any service provider. </p>
    <p>Unless explicitly committed by Confirmtkt as a part of any product or service: </p>
    <p class="MsoListParagraphCxSpFirst"> Confirmtkt assumes no liability for the standard of services as provided by
      the respective service providers. </p>
    <p class="MsoListParagraphCxSpMiddle"> Confirmtkt provides no guarantee with regard to their quality or fitness as
      represented. </p>
    <p class="MsoListParagraphCxSpLast"> Confirmtkt doesn’t guarantee the availability of any services as listed by a
      service provider. </p>
    <p>By making a booking, Customer understands Confirmtkt merely provides a technology platform for booking of
      services and products and the ultimate liability rests on the respective service provider and not Confirmtkt.
      Thus, the ultimate contract of service is between Customer and service provider.</p>
    <p>Customer further understands that the information displayed on the Website with respect to any service is
      displayed as furnished by the service provider. Confirmtkt, therefore, cannot be held liable in case the
      information provided by the service provider is found to be inaccurate, inadequate or obsolete or in contravention
      of any laws, rules, regulations or directions in force.</p>
  </section>
 
  <section>
    <h2><b>USER DATA</b></h2>
    <p>We will maintain certain data that you transmit to the Site for the purpose of managing the Site, as well as data
      relating to your use of the Site. Although we perform regular routine backups of data, you are solely responsible
      for all data that you transmit or that relates to any activity you have undertaken using the Site.</p>
    <p>You agree that we shall have no liability to you for any loss or corruption of any such data, and you hereby
      waive any right of action against us arising from any such loss or corruption of such data. </p>
  </section>
  <section>
    <h2><b>ELECTRONIC COMMUNICATIONS, TRANSACTIONS, AND SIGNATURES</b></h2>
    <p>Visiting the Site, sending us emails, and completing online forms constitute electronic communications. You
      consent to receive electronic communications, and you agree that all agreements, notices, disclosures, and other
      communications we provide to you electronically, via email and on the Site, satisfy any legal requirement that
      such communication be in writing.</p>
    <p>YOU HEREBY AGREE TO THE USE OF ELECTRONIC SIGNATURES, CONTRACTS, ORDERS, AND OTHER RECORDS, AND TO THE ELECTRONIC
      DELIVERY OF NOTICES, POLICIES, AND RECORDS OF TRANSACTIONS INITIATED OR COMPLETED BY US OR VIA THE SITE.</p>
    <p>You hereby waive any rights or requirements under any statutes, regulations, rules, ordinances, or other laws in
      any jurisdiction which require an original signature or delivery or retention of non-electronic records, or to
      payments or the granting of credits by any means other than electronic means. </p>
    <p>For ease of Users, we also send booking confirmations, itinerary information, cancellations, payment
      confirmation/status, refund status, booking failure information or any such other information relevant to the
      transaction or booking made by the User, via SMS, internet-based messaging applications like WhatsApp, voice call,
      e-mail or any other alternate communication information furnished by the User at the time of booking.</p>
    <p>You hereby consent that any such communication through SMS, WhatsApp, voice call, email or any other mode by us
      are:</p>
    <ol start="1" type="1">
      <li>as per your request and authorization;</li>
      <li>‘transactional’ and not an ‘unsolicited commercial communication’ as per the guidelines of Telecom Regulation
        Authority of India (TRAI), and</li>
      <li>in compliance with appropriate guidelines of TRAI or other relevant authority in India and abroad as
        applicable.</li>
    </ol>
    <p>You hereby agree to indemnify us against any losses and damages incurred by us due to any action taken by TRAI or
      any other authority due to any erroneous complaint filed by the User on us on account of communications sent to
      User as above or failed communication due to a wrong number or email ID shared by the User for any reason
      whatsoever.</p>
  </section>
  <section>
    <h2><b>TCS COMPLIANCE </b></h2>
    <p>TCS on Overseas tour packages:</p>
    <p>'Overseas tour package' means any tour package which offers visit to a country or countries or territory or
      territories outside India and includes expenses for travel or hotel stay or boarding or lodging or any other
      expenditure of similar nature or in relation thereto.</p>
    <p>‘Specified Person’ means a person defined as per provisions of Section 206CCA(3) of Income Tax Act, 1961.</p>
    <p>The User is liable to pay Tax collected at source (TCS) on booking of an ‘Overseas tour package’ at an
      appropriate rate over and above the price charged for such package in compliance with the provisions of Section
      206C (1G)(b) of the Income Tax Act, 1961. Confirmtkt will deposit the TCS amount so collected with the Government
      and issue appropriate document/certificate to the User in compliance with aforesaid provision.</p>
    <p>The User is required to provide a valid PAN of User/Traveler(s) at the time of booking an overseas tour package
      with Confirmtkt. The User understands and agrees that Confirmtkt, at the time of booking or at a later stage, will
      validate the PAN provided by the User to check compliance of provisions of Section 206CC of Income Tax Act. The
      User agree that in case the PAN is found to be invalid, or it does not belong to User/traveler(s), Confirmtkt has
      an obligation to cancel the booking in compliance with the law and process the refund as per the cancellation
      policy applicable to said booking.</p>
    <p>The User further understand and agrees that Confirmtkt would also, at the time of booking or at a later stage,
      validate User/traveler(s) PAN as per the provisions of Section 206CCA of Income Tax Act and if on validation the
      User qualifies as a ‘Specified person’, the User agrees to pay TCS to Confirmtkt at such higher rate as may be
      applicable under section 206CCA. The User agrees to pay the additional TCS amount to Confirmtkt where, as a result
      of validation under section 206CCA, the TCS collected at the time of booking fall short of the applicable rate of
      TCS. If User fails or disagree to pay the additional TCS, Confirmtkt has the right to cancel the booking and
      process appropriate refund as per the cancellation policy applicable to such booking. </p>
  </section>
     <section>
    <h2><b>GRIEVANCE REDRESSAL</b></h2>
    <p>Confirmtkt strongly believes in resolving the issues raised by the User(s). In the event if user feels that
      his/her concern has not been resolved to their satisfaction, User may contact our grievance officer, who shall
      endeavour to redress the concern within 30 days from the date of escalation. To reach the grievance officer please
      email on <a href="#">usersecures@gmail.com</a> . User(s) are advised to escalate to
      the grievance officer only when they have already raised their complaint which has not been resolved to their
      satisfaction, or their concern has not been resolved within 30 days from the date of ticket generation. User(s)
      will be required to share their booking reference number and the ticket ID generated for their complaint. </p>
    <p> In compliance of the Information Technology Act, 2000 and rules made there under and also in compliance of the
      Consumer Protection (E-Commerce) Rules, 2020 the name and contact details of the Grievance Officer are herein as</p>
    <div>
      <div>Name: M D PATEL</div>
      <div>Email ID: shreetravels@gmail.com</div>
      <div>Contact Number: +91-9510138383</div>
    </div>
    <p></p>
  </section>
  <section>
    <p><b>TERMS OF SERVICE</b></p>
    <p>All Services offered on Site shall be governed by the following Terms of Service:</p>
    <ul type="disc">
      <li><b>BUSES</b></li>
    </ul>
    <p> Confirmtkt acts as a facilitator for Users to book and search for desired train tickets on IRCTC platform. All
      train bookings or reservations made on the Site are subject to the applicable terms and conditions set out by
      IRCTC. <b>Booking Process</b>To book train tickets, User will be redirected to IRCTC website/application. Users
      will need their IRCTC username and password in order to book their tickets on Confirmtkt website/application.
      E-tickets are booked and issued through Indian Railways only and are subject to the rules and policies of Indian
      Railways. Users can book a maximum of 6 seats/ berths in a booking. Seat/ berth allotment is done by Indian
      Railways based on their allocation logic. Confirmtkt does not guarantee allotment of preferred seat/ berth. Users
      with a confirmed e-ticket are permitted to board the train. Their names will appear on the chart. Fully waitlisted
      e-tickets are automatically cancelled by IRCTC after chart preparation. If fully waitlisted passengers are found
      travelling, they will be treated as without-ticket and charged as per Railway rules. Booked tickets are
      non-transferrable and are subject to identification. Users must carry valid ID proof such as PAN card/ Aadhar
      Card/ Voter ID etc. at the time of travel or boarding the train for validation. Confirmtkt will not be responsible
      for any schedule change by the Railways. Users are advised to confirm their train timings 24 hours prior to the
      train departure.The Railways rules and regulations may change from time to time. Please refer to<a href="http://www.indianrail.gov.in/enquiry/StaticPages/StaticEnquiry.jsp?StaticPage=index.html">http://www.indianrail.gov.in/enquiry/StaticPages/StaticEnquiry.jsp?StaticPage=index.html</a>for
      the latest rules and regulations. While we endeavor to keep the rules and regulations updated at all times but
      should not be held responsible for the same.Please reach out to IRCTCdirectly for all relevant information/
      queries relating to your bookings. </p>
    <p><b>Modifications</b>Confirmtkt cannot make any modifications to the booked tickets, including but not limited to
      change in passenger names, change in route, boarding point etc. Any modifications to booked tickets can be made
      only by IRCTC. We suggest Users to read IRCTC amendment policy here<a href="https://www.services.irctc.co.in/beta_htmls/Eticket_new_cancel.html">https://www.services.irctc.co.in/beta_htmls/Eticket_new_cancel.html</a>to
      know more details. </p>
    <p><b>Payments, Cancellations and Refunds </b>Cancellation of booked tickets are subject to IRCTC cancellation
      policy and charges as per time of cancellation and booking quota (tatkal/ general/ ladies/ premium, etc.)
      Customers are advised to go through IRCTC cancellation policy prior to cancellation to know about the relevant
      cancellation charges. You can cancel a train ticket booked via Confirmtkt, only before chart
      preparation.Cancellation charges may vary depending on ticket type and time of ticket cancellation. Cancellations
      and refunds will be based on Indian Railways refund and TDR filing rules. These rules are subject to change by
      Indian Railways.You can find complete details of the Railway cancellation policy and rules here:<a href="http://www.indianrail.gov.in/enquiry/StaticPages/StaticEnquiry.jsp?StaticPage=refund_Rules.html&amp;locale=en">
        http://www.indianrail.gov.in/enquiry/StaticPages/StaticEnquiry.jsp?StaticPage=refund_Rules.html&amp;locale=en</a><br>or<a href="http://contents.irctc.co.in/en/eticketCancel.html">http://contents.irctc.co.in/en/eticketCancel.html</a>Payment
      Gateway charges/service fee charged by Confirmtkt at the time of booking the tickets are non-refundable. The
      refund gets credited to Wallet and/or same User bank account/credit card/debit card/wallet, etc. used for booking
      tickets unless User has chosen for instant refund through any other payment mode, after deducting the applicable
      Confirmtkt ’s charges.</p> <a href="http://www.indianrail.gov.in/enquiry/StaticPages/StaticEnquiry.jsp?StaticPage=refund_Rules.html&amp;locale=en">http://www.indianrail.gov.in/enquiry/StaticPages/StaticEnquiry.jsp?StaticPage=refund_Rules.html&amp;locale=en</a><br>or<a href="http://contents.irctc.co.in/en/eticketCancel.html">http://contents.irctc.co.in/en/eticketCancel.html</a>
    
    
   
    <ul type="disc">
      <li>Departure or arrival of the buses on time;</li>
      <li>The conduct/behaviour of bus driver or bus operator’s employees, representatives or agents;</li>
      <li>The physical condition of the bus, seats etc. not being up to the User’s expectation or as per the description
        furnished by the bus operator on the Platform;</li>
      <li>Cancellation of the scheduled trip due to any reasons;</li>
      <li>Loss or damage to the User’s luggage;</li>
      <li>Change in allocated seat to the User by the bus operator for any reason whatsoever;</li>
      <li>Bus operator notifying an incorrect boarding point on the booking confirmation voucher, or altering such
        boarding point later with or without any notification to Confirmtkt or the User;</li>
      <li>Bus operators use a different pick-up vehicle for transportation of the customers from the designated boarding
        point to the actual place of departure of the bus. Users are hereby recommended to get in touch with the bus
        operators in advance for details relating to exact boarding point, charges for additional baggage (if any) or
        any other information needed for boarding or travel for the scheduled journey.Users are required to carry
        following documents at the time of boarding the bus:</li>
      <ul type="disc">
        <li>a printout of the ticket, and</li>
        <li>any valid ID like Aadhar card, passport, PAN card or voter ID or any other valid identity proof issued by a
          government authority.</li>
      </ul>
      <p>Users are advised to reach the boarding place no later than thirty (30) minutes before the scheduled departure
        time. All tickets issued shall be non-transferable.</p>
     
    </ul>
  </section>


</body></html>