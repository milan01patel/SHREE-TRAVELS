<?php
$con=mysqli_connect("localhost","root","","shree");

	$id=$_GET['id'];
	
	$delete = mysqli_query($con,"DELETE FROM `routes` WHERE id='$id'");
	
	if($delete)
	{
        echo '<script>alert("ROUTE DELETE..");</script>';
		echo "<script>window.location.href='a-schedule.php'</script>";
	}
	else
	{
		echo "fail";
	}
		

?>
