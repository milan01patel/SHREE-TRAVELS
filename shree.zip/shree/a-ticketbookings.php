<?php 
include('header.php');
include('db.php');
include('session.php'); 
?>
 
 <!-- *************** back button ****************** -->
 <div class="container">
<button type="button" class="btn"><a href="a-allbookinfo.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- ***********************bookings table********************* -->
<div class="container mt-2" >
<table class="table table-warning table-hover table-striped text-capitalize border border-dark border-3 text-center ">
  <thead style="color:maroon;">
    <tr class="fs-4">
      <th scope="col" class="pb-5 pt-4">booking id</th>
      <th scope="col" class="pb-5 pt-4">name</th>
      <th scope="col" class="pb-5 pt-4">email</th>
      <th scope="col" class="pb-5 pt-4">date</th>
	  <th scope="col" class="pb-5 pt-4">source</th>
      <th scope="col" class="pb-5 pt-4">destination</th>
	  <th scope="col" class="pb-5 pt-4">type</th>
	  <th scope="col" class="pb-5 pt-4">view</th>
    </tr>
  </thead>
	<tbody >
	<?php 
		$con =mysqli_connect("localhost","root","","shree");
		$no =0;
		$select=mysqli_query($con,"SELECT * FROM `bookings`");
		while ($row=mysqli_fetch_array($select))
		{ 
			$no=$no+1;	
	 ?>
		<tr >
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['bookid']; ?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['firstname'] ;?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['email'];?></td>
			<td class="pt-4 pb-4 fs-5"><?php echo $row['date'];?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['source'];?></td>
            <td class="pt-4 pb-4 fs-5"><?php echo $row['destination'];?></td>
            <td class="pt-4 pb-4 fs-5"><?php echo $row['type'];?></td>
            <td><button>ok</button></td>
        </tr>
		
	<?php } ?>
	</tbody>
</table>
</div>
