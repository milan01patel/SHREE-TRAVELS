<div>
<footer class="footer" >
  <div>
    <a href="term.php">Term & Condition <br>
    </a>
    <a href="admin.php" class="text-danger">admin_login
    </a>
  </div>
  <div style="color:white;">
    <b>©</b>2024 Copyright : SHREE TRAVELERS & TOORS<br>
    <a style="color:white; font-size:25px;" href="https://instagram.com/milan_______022/"><i class="fa-brands fa-instagram"></i></a>
    <a style="color:white; font-size:25px;" href="https://facebook.com/"><i class="fa-brands fa-facebook"></i></a>
    <a style="color:white; font-size:25px;" href="https://twitter.com/"><i class="fa-brands fa-twitter"></i></a>
    <a style="color:white; font-size:25px;" href="https://gmail.com/"><i class="fa-solid fa-envelope"></i></a>
  </div>
</footer>
</div>