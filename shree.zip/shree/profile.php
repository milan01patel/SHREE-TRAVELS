<?php
include('header.php');
include('db.php');
include('session.php');
$result=mysqli_query($con,"SELECT * FROM `users` WHERE `email`='$session_email'")or die('Error In Session');
$row=mysqli_fetch_array($result);
?>
<!-- *************** back button ****************** -->
<div class="container">
<button type="button" class="btn"><a href="busbook.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- -------------------------------------------------- -->
<div class="card rounded-pill" style="color:maroon; background-color:#fff8dc;"><h3 class="p-2"><img src="img/wel.png"/> "<b><?php echo $row['name']; ?></b>" It`s Your Information</h3></div>
<div class="card rounded p-4 fs-5" style="color:maroon; background-color:#fff8dc;">
    <table>
    <tr>
        <td>CONTACT :</td>
        <td>
        <b><?php echo $row['number']; ?></b>
        </td>
    </tr>

    <tr>
        <td>EMAIL :</td>
        <td>
        <b><?php echo $row['email']; ?></b>
        </td>
    </tr>
    <tr>
        <td>PASSWORD :</td>
        <td>
        <b><?php echo $row['password']; ?></b>
        </td>
    </tr>
    <tr>
        <td>GENDER :</td>
        <td>
        <b><?php echo $row['gender']; ?></b>
        </td>
    </tr>
    <tr>
        <td>DATE OF BIRTH:</td>
        <td>
        <b><?php echo $row['dob']; ?></b>
        </td>
    </tr>

</table>
</div>

<div class="container" style="text-align:center; margin-top:50px;"> 
<a href="edit.php"><button type="button" class="btn btn-outline-secondary">EDIT PROFILE </button></a>&nbsp
<a href="logout.php"><button type="button" class="btn btn-outline-secondary">LOGOUT</button></a>

</div><br>