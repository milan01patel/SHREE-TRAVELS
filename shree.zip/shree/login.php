<!--LOGIN Page-->
<?php     
	include('header.php');
    include('db.php');
?>
<?php session_start(); ?>
<br><br>

<div><center><img src="img/user.png"/></center></div>
<div>
	<h2><center><b>User Login</center></b></h2><br>
</div>
<br><br><br>

<center>
<div>
<form method="post" action="" enctype="multipart/form-data" class="logb">   
<!-- style="background-color: rgba(120, 50, 0, 0.350); border-radius:30px; width:400px;" -->
<tr>
            <td><br>
                <h3>EMAIL ID : </h3></td> 
                <td colspan="2"><input type="email" style="background-color:#FFF8DC;" name="email" maxlength="50" required>
            </td>
        </tr>
        <br><br>
        <tr>
            <td>
                <h3>PASSWORD : </h3></td> <td colspan="2"><input type="password" style="background-color:#FFF8DC;" name="password" maxlength="50" required>
            </td>
        </tr>
        <br><br>
        <tr>
            <td colspan="3">
                    <center><button type="Submit" class="btn btn-warning" name="login">log In</button></center><br>
            </td>
        </tr>
</form>
</div>
<br>
<!-- ----------------------------- when not register ----------------------------------- -->
</center>
<div align="center" style="padding-bottom:30px;">
<h3><a href='register.php' style="color:maroon; text-decoration:none;"> Register</a></h3>
<h6><a href='forget.php' style="color:red; text-decoration:none;"> Forget Password !!</a></h6>
</div>
<!-- ----------------------------------------------------------------------------------- -->

<?php
	if (isset($_POST['login']))
		{
			$email = mysqli_real_escape_string($con, $_POST['email']);
			$password = mysqli_real_escape_string($con, $_POST['password']);
			
			$query = mysqli_query($con,"SELECT * FROM users WHERE  `email`='$email' and `password`='$password'");
			$row= mysqli_fetch_array($query);
			$num_row = mysqli_num_rows($query);
			if ($num_row > 0) 
				{			
					$_SESSION['email']=$row['email'];
					header('location:busbook.php');
				}
			else
				{
					echo '<script>alert("Invalid Email Or Password Combination");</script>';
				}
		}
  ?>
<!-- <?php include ('footer.php') ?>  -->
