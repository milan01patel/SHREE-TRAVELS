<?php 
include('header.php');
include('db.php');
include('session.php'); 
?>
   <!-- *************** back button ****************** -->
   <div class="container">
<button type="button" class="btn"><a href="mybooking.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- ************************************** -->
<div class="container mt-2" >
<table class="table table-warning table-hover table-striped text-capitalize border border-dark border-3 text-center ">
  <thead style="color:maroon;">
    <tr class="fs-4">
      <th scope="col" class="pb-5 pt-4">booking id</th>
      <th scope="col" class="pb-5 pt-4">name</th>
      <th scope="col" class="pb-5 pt-4">from</th>
      <th scope="col" class="pb-5 pt-4">to</th>
      <th scope="col" class="pb-5 pt-4">type</th>
    </tr>
  </thead>
	<tbody >
	<?php 
		$con =mysqli_connect("localhost","root","","shree");
		$no =0;
		$select=mysqli_query($con,"SELECT * FROM `fullseat_bookings` WHERE `email`='$session_email'");
		while ($row=mysqli_fetch_array($select))

		{ 
			$no=$no+1;	
	 ?>
		<tr >
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['bookcode']; ?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['name'] ;?></td>
             <td class="pt-4 pb-4 fs-5"><?php echo $row['datefrom']; ?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['dateto'] ;?></td>
	 	    <td class="pt-4 pb-4 fs-5"><?php echo $row['type'] ;?></td>
<!-- <td class="pt-4 pb-4"><a class="btn btn-success btn-sm text-light" name="gobook" href="gotobook.php?id=<?php echo $row['id'];?>"> G O &nbsp FOR &nbsp B O O K</a></td>  -->
	 	</tr>
		
	<?php } ?>
	</tbody>
</table>
</div>
