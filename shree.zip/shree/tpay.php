<?php
  session_start();
    include("header.php");
    include("db.php");
    if(isset($_POST['book']))
    {
      $fname = $_POST['fname'];
      $lname = $_POST['lname'];   
      $email = $_POST['email'];
      $date = $_POST['date']; 
      $from = $_POST['from'];
      $to = $_POST['to'];
      $type= $_POST['type'];
      $time= $_POST['time'];
      $price= $_POST['price'];
      $bookid="SRT".rand(100001,999999);
      ?>
      <div class="container mt-5 bg-transparent " >
          <form method="POST" class="row g-3 mt-3 fs-5 text-light p-4 rounded text-center" style="margin:25%; background-color: rgba(0, 0, 0, 0.750);">
            <div class="mb-3 "><b>MAKE A FEW EASY STEP AND BOOK TICKET</b></div>
            <div class="col-md-6 ">
              <label for="inputText" class="form-label">card number</label>
              <input type="text" name="cardnumber" class=" form-control text-center"  id="inputtext" required>
            </div>
            <div class="col-md-6 ">
              <label for="inputText" class="form-label">pin</label>
            <input type="text" name="pin" class=" form-control text-center"  id="inputtext" required>
          </div>
          <div class="col-md-6 ">
            <label for="inputText" class="form-label">price</label>
           <input type="text" name="price" class=" form-control text-center" value="<?php echo $price; ?>" readonly  id="inputtext" required>
          </div>

          <input name="fname" type="hidden" value="<?php echo $fname;?>">
          <input name="lname" type="hidden" value="<?php echo $lname;?>">
          <input name="email" type="hidden" value="<?php echo $email;?>">
          <input name="date" type="hidden" value="<?php echo $date;?>">
          <input name="from" type="hidden" value="<?php echo $from;?>">
          <input name="to" type="hidden" value="<?php echo $to;?>">
          <input name="type" type="hidden" value="<?php echo $type;?>">
          <input name="time" type="hidden" value="<?php echo $time;?>">
          <input name="price" type="hidden" value="<?php echo $price;?>">
          <input name="bookid" type="hidden" value="<?php echo $bookid;?>">

          <button name="pay">pay</button>
        </form>
        <?php 
      }
            if(isset($_POST["pay"]))
            {
              $fname = $_POST['fname'];
              $lname = $_POST['lname'];   
              $email = $_POST['email'];
              $date = $_POST['date']; 
              $from = $_POST['from'];
              $to = $_POST['to'];
              $type= $_POST['type'];
              $time= $_POST['time'];
              $price= $_POST['price'];
              $bookid= $_POST['bookid'];
              $cardnumber =$_POST['cardnumber'];
              $pin =$_POST['pin'];   
              $con= mysqli_connect("localhost","root","","shree");
              $ins = mysqli_query($con,"INSERT INTO bookings(firstname,lastname,email,date,source,destination,type,time,price,bookid) VALUES('$fname','$lname','$email','$date','$from','$to','$type','$time','$price','$bookid')");

              // *****************************************
              $pay = mysqli_query($con,"INSERT INTO ticket_pay(cardnumber,pin,price) VALUES('$cardnumber','$pin','$price')");
              // *****************************************
              if($ins)
              {
                echo '<script>alert("Thank you for your recent booking.")</script>';
                // header('location:mybooking.php');
                
              }
              else
              {
                  echo "Fail";
                }
            }
            else
            {
              echo "chal be chal";
            }
    ?>

</div>
<?php
// ins = mysqli_query($con,"INSERT INTO `bookings`(`firstname`,`lastname`,`email`,`date`,`source`,`destination`,`type`,`time`,`price`,`cardnumber`,`pin`,`bookid`)
//     VALUES('$fname','$lname','$email','$date','$from','$to','$type','$time','$price','$cardnumber','$pin','$bookid')");
?>