<?php
    include("header.php");
?>
<!-- *************** back button ****************** -->
<div class="container">
<button type="button" class="btn"><a href="allinfo.php"> <img src="img/back.png" alt=""></a></button>
</div>
<!-- ********************************************* -->
<div class="container text-center mt-5">
  <div class="row " >
    <div class="col">
    <p class=" bg-light rounded-pill text-danger font-monospace">✧ TICKET BOOKINGS ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="a-ticketbookings.php"> <img src="img/book1.png" alt=""></a></button>
    </div>
    <div class="col">
    <p class=" bg-light rounded-pill text-danger font-monospace">✧ FULL BUS BOOKINGS ✧<br>click below ↓</p>
    <button type="button" class="btn"><a href="a-fullbookings.php"> <img src="img/book2.png" alt=""></a></button>
    </div>
  </div>
</div>