<?php 
include('db.php');
include('session.php'); 

?>
<?php 
      $select=mysqli_query($con,"SELECT * FROM `users` WHERE `email`='$session_email'");
      $row=mysqli_fetch_array($select);
?>
<?php 

    if(isset(
    
        $_POST['change'])){  
        $name =$_POST['name'];
        $number =$_POST['number'];
        $email =$_POST['email'];
        $password =$_POST['password'];
      
    $edits = mysqli_query($con,"UPDATE `users` SET `name`='$name',`number`='$number',`password`='$password' WHERE `email` = '$session_email'");
        
     if($edits)
     {
           header("location:profile.php"); 
     }
     else{
      echo 'fail';
     }
    }
?>

<div class="container py-5 mt-5 border bg-warning ">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      
  <form method="POST" enctype="multipart/form-data">
      <label > CHANGE YOUR PROFILE FROM HERE</label>
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Name</label>
        <input type="text" class="form-control" value="<?php echo $row['name'];?>" name="name" >
      </div>
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Mobile</label>
        <input type="number" class="form-control" value="<?php echo $row['number'];?>" name="number" >
      </div>
      <div class="mb-3">
        <label for="disabledTextInput" class="form-label">Email (IT`S NOT FOR CHANGE)</label>
        <input  id="disabledTextInput" class="form-control" disabled="disabled"  value="<?php echo $row['email'];?>">
      </div>
      <!-- <div class="mb-3">
        <label for="disabledTextInput" class="form-label">Email(IT`S NOT CHANGEABLE)</label>
        <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['email'];?>" name="email">
      </div> -->
      <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" value="<?php echo $row['password'];?>" name="password" >
      </div>
      <button type="submit" class="btn btn-secondary" name="change">CHANGE</button>
  </form>
</div>
    <!-- bootstrap javascript link -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

   
