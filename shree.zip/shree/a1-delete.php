
<?php   
 include 'db.php';  
 if (isset($_GET['id'])) 
 {  
      $id = $_GET['id'];  
      $query = "DELETE FROM `routes` WHERE `id` = '$id'";  
      $run = mysqli_query($con,$query); 
      echo("deleted"); 
      if ($run) {  
            header('location:a-schedule.php');  
       }else{  
            echo "Error: ".mysqli_error($con);  
       }  
 }  
 ?>  