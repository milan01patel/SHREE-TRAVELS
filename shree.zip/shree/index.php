<!-- ******************HEADER PART******************* -->
<?php 
include('header.php');
?>

<!-- ------------------------options--------------------- -->
<div class="opt sticky-top">
<a href='login.php' class="animate__animated animate__shakeY"><button type="button" class="btn btn-warning"><i class="fa-solid fa-user"></i> USER LOGIN </button></a>
</div>
<!-- ******************WELCOME PART**************** -->
<div>
    <div class="wel" style="margin-top:130px;">
         <img src="img/bus.png" alt="bus" class="bus animate__animated animate__rotateIn"><br><img src="img/ticket.png" alt="logo"> Welcome To <b>SHREE</b> Bus Ticket Booking Portal <img src="img/ticket.png" alt="logo" >
         <br>
         <a href="login.php"><button type="submit" class="btn btn-danger" name="change">Go To Booking </button></a><br>
         <div class="container badge text-dark fs-5 mt-4 rounded-pill" style=" padding:20px;font-family: papyrus; background-color:#ffe699;">* We will give you comfortable and luxury services on your trip,who feel you 'LUXURY'.</div>
    </div>
</div>
<!-- -----------------------about------------------------- -->

<div class="container text-center text-danger" style="margin-top:100px; ">
        <h1>ABOUT US</h1>
</div>
<div class="clearfix container mt-5" style=" border-radius:20px;  background-color:rgba(247, 195, 112, 0.20);">
  <img src="img/bus1.jpg" class="col-md-6 float-md-end mb-3 ms-md-3 mt-3 rounded-pill " alt="...">
  <br>
  <h4>' SHREE TOORS & TRAVELS '</h4>
  <br><br>
  <p>
  A tours and travels company you can rely on, when it comes <br> to a comfortable journey throughout.
  </p>

  <p>
  We are dedicated to give you top notch Quality of Service,<br> through a good variety of dedicated Buses to choose from.
  </p>
  <p>
  We desire to gain true confidence and win hearts of our Customers <br> by providing Good Service and punctuality, as we Value our Customers and their Time. 
  </p>
  <p>
  Our Staff is Professionally trained.
  </p>
</div>

<!-- -----------------------services------------------------ -->
<div class="container text-center mt-5 text-danger">
        <h1>SERVICES</h1><button type="button" class="btn"><a href="bus-set.php"> <img src="img/bus-set1.png" alt=""></a></button>
        <p>We offer the best amenities to make our passenger`s journey more pleasant.</p>
</div>
<br>
<div class="container">
  <div class="row justify-content">
    <div class="col-4">  
    <img src="img/services/sleep.png" alt=""> 
    <b>COMFY SLEEPERS</b>
    <p>Unwind in our clean and secure sleeper berths.</p>
    </div>
    <div class="col-4">
    <img src="img/services/charge.png" alt="">
    <b>CHARGING POINT</b> 
    <p>We will provides charging on seat.</p>
    </div>
    <div class="col-4">
    <img src="img/services/semi.png" alt="">
    <b>SEMI-SLEEPER</b>
    <p>Semi-Sleeper is the golden chain that ties health. </p>
    </div>
  </div>
  <br>
  <div class="row justify-content-center">
  <div class="col-4">
    <img src="img/services/pillow.jpeg" alt="">
    <b> &nbspPILLOW & BLANKET</b>
    <p>It`s provide on sleeper bus trip only.</p>
  </div>
  <div class="col-4">
    <img src="img/services/wash.png" alt=""><img src="img/services/wash1.png" alt="">
    <b>TRAVEL RELAXED</b>
    <p>Sanitized in bus-washrooms for your comfortable travel.  </p>
  </div>
  </div>
  <br>
  <div class="row justify-content-between">
    <div class="col-4">
     <img src="img/services/clean.png" alt="">
      <b>SANITIZED AMENITIES AND INTERIORS.</b>
    </div>
    
    <div class="col-4">
      <img src="img/services/staff.png" alt="">
      <b>HIGHLY EXPERIENCED AND TRAINED CREW.</b>
    </div>
  </div>
  <br>
  <div class="row justify-content-center">
    <div class="col-4">
      <img src="img/services/wifi.png" alt="">
      <b>PROVIDE A WIFI.</b>
    </div>
    <div class="col-4">
      <img src="img/services/water.png" alt="">
      <b>PROVIDE A WATER-BOTTLE.</b>
    </div>
  </div>
  <br>
  <br>
  <div class="row justify-content-around">
    <div class="col-4">
     <img src="img/services/help.png" alt="">
      <b>EMERGENCY HELPLINE NUMBERS.</b>
    </div>
    <div class="col-4">
      <img src="img/services/fire.png" alt="">
      <b>FIRE EXTINGUISHER.</b>
    </div>
    <div class="col-4">
     <img src="img/services/exit.png" alt=""><img src="img/services/exit1.png" alt="">
      <b>EMERGENCY EXIT WITH HAMMER.</b>
    </div>
  </div>
</div> 
<br><br>
<!-- -----------------------more------------------------ -->
<div class="container  text-center mt-5 text-danger">
        <h1>WHY SHREE TRAVELS</h1>
</div>
<div class="container"  style="margin-top:50px; border-radius:20px;  background-color:rgba(247, 195, 112, 0.20);">
  <div class="row row-cols-2">
    <div class="col" style="margin-top:50px;">
        <h4>Make Your Bus Booking Smoother With SHREE </h4>
        <h5>Imagine the thrill of feeling the wind in your hair, while looking at the changing scenes from a window-seat, in a bus. Makes you smile, doesn’t it? Bus journeys are always filled with such memorable and fun moments, which we look back at, fondly. And in our continuous endeavour to bring to our customers the best travel experiences, we now offer smarter bus booking services on our platform. Read on to know why you should make your upcoming bus ticket bookings, online on shree.</h5>
    </div>
    <div class="col" style="margin-top:50px;">
        <h4>Reasons to Choose SHREE for Bus Booking:</h4>
        <h5>MySafety Assurance: All the buses available on our platform are MySafety-assured with regular sanitization of the vehicle carried out after every trip, regular temperature checks done on passengers before boarding the bus, and the staff following all safety protocols.
        Customer First Policy: When you complete your online bus booking on MakeMyTrip, be sure of getting the highest standards of customer service, including regular trip-related updates on your device.</h5>
    </div>
    <div class="col" style="margin-top:50px;">
        <h4>Advantages of booking bus tickets online on SHREE</h4>
        <h5>The most important part of any trip is planning because if you plan well, you are sure to enjoy your trip better. And online bus bookings allow you just that. You can check for bus routes to your destination, compare prices with other nearby routes, choose from AC/non-AC buses as per your preference and more, all within a few minutes and with just a few taps on your phone. You can also avail of immediate cancellation in case of a sudden change in plans, within a few seconds, and without the hass...</h5>
    </div>
    <div class="col" style="margin-top:50px;">
        <h4>What`s more?</h4>
        <h5>Online bus ticket booking also gives you the freedom to choose your mode of payment. No more do you have to carry cash or pay for your tickets in cash. You can avail a variety of payment modes when you choose to book bus online on MakeMyTrip. Here below is a list of the payment modes available on our platform: Debit Card, Credit Card & Net Banking with banks like: HDFC Bank, ICICI Bank, Axis Bank, State Bank of India and many more, UPI mode of payment, Trip Money, Wallet & more , Google Pay, Pho...</h5>
    </div>
    <div class="col" style="margin-top:50px;">
        <h4>Why SHREE for Bus Booking?</h4>
        <h5>The leading player in online Bus bookings in India, SHREE offers lowest fares, exclusive discounts and a seamless online booking experience. Desktop or mobile site is a delightfully customer friendly experience, and with just a few clicks you can complete your booking.</h5>
    </div>
    <div class="col" style="margin-top:50px;">
        <h4>Booking Bus Ticket with SHREE GROUP</h4>
        <h5>SHREE's online bus reservation system is simpler and smarter. It provides you a wide range of facilities, right from choosing your pickup point to your preferred choice of seat (for instance, luxury buses with sleeper berths). You can also choose from the widest range of available buses like Mercedes, Volvo, luxury, Deluxe, Sleeper, Express and other private buses. The payment opt...</h5><br>
    </div>
  </div>
</div>

<!-- --------------------------------contact------------------------- -->
<div class="con">
  <div class="container text-center"> 
      <div class="text-danger">
          <h1>CONTACT WITH US</h1><br>
      </div>
      <div class="container" >
        <div class="container text-left" >  
            <div class="address">
              <i class="fa-solid fa-location-dot"></i>
              <h4>Location:</h4>
              <p>SHREE TRAVELS,MAJEVDI GAIT,JUNAGADH,GUJRAT-362001</p>
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <h4>Email:</h4>
              <p>shreetravel@gmail.com</p>
              <i class="fa-solid fa-mobile"></i>
              <h4>Call:</h4>
              <p>+91 65444 54321</p>
            </div>      
        </div>  
      </div>
  

  <div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d879.2339169714762!2d70.44615356369404!3d21.539177950079146!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1717824337012!5m2!1sen!2sin" width="60%" height="300px" style="border:2px solid maroon; border-radius:20px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  </div>

</div>
</div>
<!-- -------------------------feedback-------------------------- -->
<div class="p-5 text-center mt-5">
  <div class="row">
  <h1 class="text-danger mb-5">HELP & FEEDBACK</h1>
  <div class="col"></div>
  <div class="col border border-3 border-warning rounded" style="background-color:rgba(247, 195, 112, 0.20);">
      
      <form method="post" role="form" class="php-email-form p-3 " enctype="multipart/form-data">
              <div class="row mt-3">
                <div class="form-group col-md-6">
                  <label for="name" class="mb-2 fw-bolder">Your Name</label>
                  <input type="text" style="background-color:#FFF8DC;" name="name" class="form-control rounded" id="name" required="" fdprocessedid="hjgi8">
                </div>
                <div class="form-group col-md-6 mt-3 mt-md-0">
                  <label for="name" class="mb-2 fw-bolder">Your Email</label>
                  <input type="email" class="form-control rounded" style="background-color:#FFF8DC;" name="email" id="email" required="" fdprocessedid="cty4xq">
                </div>
              </div>
              <div class="form-group mt-3">
                <label for="name" class="mb-2 fw-bolder">Subject</label>
                <input type="text" class="form-control rounded " style="background-color:#FFF8DC;" name="subject" id="subject" required="" fdprocessedid="kmk79">
              </div>
              <div class="form-group mt-3">
                <label for="name" class="mb-2 fw-bolder">Message</label>
                <textarea class="form-control rounded" style="background-color:#FFF8DC;" name="message" rows="4" required=""></textarea>
              </div>
              
              <div class="text-center mt-4"><button type="submit" class="btn btn-outline-dark" name="submit" fdprocessedid="o0xlg">Send Message</button></div>
      </form>
    </div>
    <?php 
     $con= mysqli_connect("localhost","root","","shree");

      if(isset($_POST['submit']))
       {
            
        $name =$_POST['name'];   
        $email =$_POST['email'];
        $subject =$_POST['subject'];
        $message =$_POST['message'];
       
        $ins = mysqli_query($con,"INSERT INTO `feedback`(`name`,`email`,`subject`,`message`)
        VALUES('$name','$email','$subject','$message')");
        if($ins)
        {
            echo "<script>alert('THANKS FOR YOUR FEEDBACK ✓');</script>";
        }
        else
        {
          echo "Fail";
        }

       }

     ?>
    <div class="col"></div>
</div>
</div>

<!-- *****************FOOTER PART****************** -->
<?php include('footer.php') ?> 

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</body>
</html>
<!-- We will give you comfortable and luxury services on your trip,who feel you in peacefull life. -->